import type {
	AssistantMessage,
	AssistantMessageEvent,
	ImageContent,
	Message,
	Model,
	SimpleStreamOptions,
	TextContent,
	ThinkingBudgets,
	Transport,
	ToolResultMessage,
} from "@super-pi/ai";
import {
	EventDeliveryDispatcher,
	type EventDeliveryDiagnostic,
	type EventDeliveryStats,
	type EventSubscriptionOptions,
} from "./event-delivery.ts";
import { runAgentLoop, runAgentLoopContinue, runHostToolDispatch } from "./agent-loop.ts";
import { getDefaultStreamFn } from "./stream-fn.ts";
import { isModelToolSelection, selectModelTools } from "./tool-exposure.ts";
import type {
	AfterToolCallContext,
	AfterToolCallResult,
	AgentContext,
	AgentChangedToolUpdate,
	AgentEvent,
	AgentEventInstrumentation,
	AgentLoopConfig,
	AgentLoopTurnUpdate,
	AgentLlmConverter,
	AgentMessage,
	AgentState,
	AgentTool,
	AgentToolCall,
	BeforeToolCallContext,
	BeforeToolCallResult,
	PrepareNextTurnContext,
	QueueMode,
	ShouldStopAfterTurnContext,
	StreamFn,
	ToolExecutionMode,
} from "./types.ts";

export type { QueueMode } from "./types.ts";

function abortRun(controller: AbortController): void {
	if (controller.signal.aborted) return;
	// A caller may retain the signal after the run. Lazy error frames must not
	// retain the agent, session, hook contexts or provider executor with it.
	const reason = new DOMException("This operation was aborted", "AbortError");
	reason.stack = "AbortError: This operation was aborted";
	controller.abort(reason);
}

function defaultConvertToLlm(messages: AgentMessage[]): Message[] {
	return messages.filter(
		(message) => message.role === "user" || message.role === "assistant" || message.role === "toolResult",
	);
}

const EMPTY_USAGE = {
	input: 0,
	output: 0,
	cacheRead: 0,
	cacheWrite: 0,
	totalTokens: 0,
	cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
};

const DEFAULT_MODEL = {
	id: "unknown",
	name: "unknown",
	api: "unknown",
	provider: "unknown",
	baseUrl: "",
	reasoning: false,
	input: [],
	cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
	contextWindow: 0,
	maxTokens: 0,
} satisfies Model<any>;

function deepFreezeSnapshot(value: unknown, seen = new WeakSet<object>()): void {
	if ((typeof value !== "object" && typeof value !== "function") || value === null || seen.has(value)) return;
	seen.add(value);
	if (value instanceof Map) {
		for (const [key, entry] of value) {
			deepFreezeSnapshot(key, seen);
			deepFreezeSnapshot(entry, seen);
		}
	} else if (value instanceof Set) {
		for (const entry of value) deepFreezeSnapshot(entry, seen);
	} else {
		for (const key of Reflect.ownKeys(value)) deepFreezeSnapshot(Reflect.get(value, key), seen);
	}
	// Freezing non-empty typed-array views throws. structuredClone has already
	// detached them from the producer, which is the required isolation boundary.
	if (!ArrayBuffer.isView(value)) Object.freeze(value);
}

type MutableAgentState = Omit<AgentState, "isStreaming" | "streamingMessage" | "pendingToolCalls" | "errorMessage"> & {
	isStreaming: boolean;
	streamingMessage?: AgentMessage;
	pendingToolCalls: Set<string>;
	errorMessage?: string;
};

function createMutableAgentState(
	initialState?: Partial<Omit<AgentState, "pendingToolCalls" | "isStreaming" | "streamingMessage" | "errorMessage">>,
): MutableAgentState {
	let tools = initialState?.tools?.slice() ?? [];
	let modelTools = selectModelTools(tools);
	let messages = initialState?.messages?.slice() ?? [];

	return {
		systemPrompt: initialState?.systemPrompt ?? "",
		model: initialState?.model ?? DEFAULT_MODEL,
		thinkingLevel: initialState?.thinkingLevel ?? "off",
		get tools() {
			return tools;
		},
		set tools(nextTools: AgentTool<any>[]) {
			tools = nextTools.slice();
			modelTools = selectModelTools(tools);
		},
		get modelTools() {
			// The returned tools array may be mutated in place; revalidate the cached projection.
			if (!isModelToolSelection(tools, modelTools)) modelTools = selectModelTools(tools);
			return modelTools;
		},
		get messages() {
			return messages;
		},
		set messages(nextMessages: AgentMessage[]) {
			messages = nextMessages.slice();
		},
		isStreaming: false,
		streamingMessage: undefined,
		pendingToolCalls: new Set<string>(),
		errorMessage: undefined,
	};
}

/** Options for constructing an {@link Agent}. */
export interface AgentOptions {
	initialState?: Partial<Omit<AgentState, "pendingToolCalls" | "isStreaming" | "streamingMessage" | "errorMessage">>;
	convertToLlm?: AgentLlmConverter;
	transformContext?: (messages: AgentMessage[], signal?: AbortSignal) => Promise<AgentMessage[]>;
	streamFn: StreamFn;
	getApiKey?: (provider: string) => Promise<string | undefined> | string | undefined;
	onPayload?: SimpleStreamOptions["onPayload"];
	onResponse?: SimpleStreamOptions["onResponse"];
	beforeToolCall?: (context: BeforeToolCallContext, signal?: AbortSignal) => Promise<BeforeToolCallResult | undefined>;
	afterToolCall?: (context: AfterToolCallContext, signal?: AbortSignal) => Promise<AfterToolCallResult | undefined>;
	shouldStopAfterTurn?: (context: ShouldStopAfterTurnContext, signal?: AbortSignal) => boolean | Promise<boolean>;
	prepareNextTurn?: (
		signal?: AbortSignal,
	) => Promise<AgentLoopTurnUpdate | undefined> | AgentLoopTurnUpdate | undefined;
	prepareNextTurnWithContext?: (
		context: PrepareNextTurnContext,
		signal?: AbortSignal,
	) => Promise<AgentLoopTurnUpdate | undefined> | AgentLoopTurnUpdate | undefined;
	steeringMode?: QueueMode;
	followUpMode?: QueueMode;
	sessionId?: string;
	thinkingBudgets?: ThinkingBudgets;
	transport?: Transport;
	maxRetryDelayMs?: number;
	toolExecution?: ToolExecutionMode;
	/** Optional structural counters for tests and benchmarks. */
	eventInstrumentation?: AgentEventInstrumentation;
	/** Receives isolated observer errors and slow-observer diagnostics. */
	onEventDeliveryDiagnostic?: (diagnostic: EventDeliveryDiagnostic) => void;
}

class PendingMessageQueue {
	private messages: AgentMessage[] = [];
	public mode: QueueMode;

	constructor(mode: QueueMode) {
		this.mode = mode;
	}

	enqueue(message: AgentMessage): void {
		this.messages.push(message);
	}

	hasItems(): boolean {
		return this.messages.length > 0;
	}

	drain(): AgentMessage[] {
		if (this.mode === "all") {
			const drained = this.messages.slice();
			this.messages = [];
			return drained;
		}

		const first = this.messages[0];
		if (!first) {
			return [];
		}
		this.messages = this.messages.slice(1);
		return [first];
	}

	clear(): void {
		this.messages = [];
	}
}

type ActiveRun = {
	promise: Promise<void>;
	resolve: () => void;
	abortController: AbortController;
};

type MessageUpdateEvent = Extract<AgentEvent, { type: "message_update" }>;
type ToolUpdatePhase = AgentChangedToolUpdate["phase"];
type ToolCallAssistantEvent = Extract<
	AssistantMessageEvent,
	{ type: "toolcall_start" | "toolcall_delta" | "toolcall_end" }
>;

interface PendingChangedToolUpdate {
	toolCallId: string;
	contentIndex: number;
	phase: ToolUpdatePhase;
	generation: string | number | undefined;
	finalized: boolean;
}

type PendingMessageUpdateEvent = MessageUpdateEvent & {
	changedToolUpdates: PendingChangedToolUpdate[];
};

function getToolUpdatePhase(event: ToolCallAssistantEvent): ToolUpdatePhase {
	if (event.type === "toolcall_start") return "start";
	if (event.type === "toolcall_delta") return "delta";
	return "end";
}

function getToolUpdateGeneration(
	content: unknown,
	event: ToolCallAssistantEvent,
): string | number | undefined {
	const eventGeneration = (event as AssistantMessageEvent & { toolArgsGeneration?: string | number })
		.toolArgsGeneration;
	if (eventGeneration !== undefined) return eventGeneration;
	if (typeof content !== "object" || content === null) return undefined;
	const block = content as {
		toolArgsGeneration?: string | number;
		partialJson?: string;
		partialArgs?: string;
	};
	return block.toolArgsGeneration ?? block.partialJson ?? block.partialArgs;
}

class AgentEventDeliveryDispatcher extends EventDeliveryDispatcher<AgentEvent, string> {
	private readonly owner: Agent;
	private readonly diagnosticListener: ((diagnostic: EventDeliveryDiagnostic) => void) | undefined;

	constructor(
		owner: Agent,
		onDiagnostic: ((diagnostic: EventDeliveryDiagnostic) => void) | undefined,
	) {
		super();
		this.owner = owner;
		this.diagnosticListener = onDiagnostic;
	}

	protected override createLatestSnapshot(event: AgentEvent): AgentEvent {
		return this.owner.snapshotObserverEvent(event);
	}

	protected override onLatestReleased(key: string, event: AgentEvent): void {
		this.owner.releaseObserverEvent(key, event);
	}

	protected override onObserverError(error: unknown): void {
		const listener = this.diagnosticListener;
		if (listener) listener({ type: "observer-error", error });
	}

	protected override onSlowObserver(durationMs: number): void {
		const listener = this.diagnosticListener;
		if (listener) listener({ type: "observer-slow", durationMs });
	}
}

/**
 * Stateful wrapper around the low-level agent loop.
 *
 * `Agent` owns the current transcript, emits lifecycle events, executes tools,
 * and exposes queueing APIs for steering and follow-up messages.
 */
export class Agent {
	private _state: MutableAgentState;
	private readonly eventDelivery: EventDeliveryDispatcher<AgentEvent, string>;
	private readonly pendingChangedToolUpdates = new Map<string, PendingChangedToolUpdate>();
	private pendingMessageUpdateEvent: PendingMessageUpdateEvent | undefined;
	private readonly eventInstrumentation?: AgentEventInstrumentation;
	private readonly steeringQueue: PendingMessageQueue;
	private readonly followUpQueue: PendingMessageQueue;
	private readonly getCurrentTools = (): readonly AgentTool<any>[] => this._state.tools;

	public convertToLlm: AgentLlmConverter;
	public transformContext?: (messages: AgentMessage[], signal?: AbortSignal) => Promise<AgentMessage[]>;
	public streamFunction: StreamFn;
	public getApiKey?: (provider: string) => Promise<string | undefined> | string | undefined;
	public onPayload?: SimpleStreamOptions["onPayload"];
	public onResponse?: SimpleStreamOptions["onResponse"];
	public beforeToolCall?: (
		context: BeforeToolCallContext,
		signal?: AbortSignal,
	) => Promise<BeforeToolCallResult | undefined>;
	public afterToolCall?: (
		context: AfterToolCallContext,
		signal?: AbortSignal,
	) => Promise<AfterToolCallResult | undefined>;
	public shouldStopAfterTurn?: (
		context: ShouldStopAfterTurnContext,
		signal?: AbortSignal,
	) => boolean | Promise<boolean>;
	public prepareNextTurn?: (
		signal?: AbortSignal,
	) => Promise<AgentLoopTurnUpdate | undefined> | AgentLoopTurnUpdate | undefined;
	public prepareNextTurnWithContext?: (
		context: PrepareNextTurnContext,
		signal?: AbortSignal,
	) => Promise<AgentLoopTurnUpdate | undefined> | AgentLoopTurnUpdate | undefined;
	private activeRun?: ActiveRun;
	private _abortRequested = false;
	/** Session identifier forwarded to providers for cache-aware backends. */
	public sessionId?: string;
	/** Optional per-level thinking token budgets forwarded to the stream function. */
	public thinkingBudgets?: ThinkingBudgets;
	/** Preferred transport forwarded to the stream function. */
	public transport: Transport;
	/** Optional cap for provider-requested retry delays. */
	public maxRetryDelayMs?: number;
	/** Tool execution strategy for assistant messages that contain multiple tool calls. */
	public toolExecution: ToolExecutionMode;

	constructor(options: AgentOptions) {
		// Older compiled consumers may omit options or streamFn even though the current API requires them.
		const runtimeOptions: Partial<AgentOptions> = options ?? {};
		this._state = createMutableAgentState(runtimeOptions.initialState);
		this.convertToLlm = runtimeOptions.convertToLlm ?? defaultConvertToLlm;
		this.transformContext = runtimeOptions.transformContext;
		this.streamFunction = runtimeOptions.streamFn ?? getDefaultStreamFn();
		this.getApiKey = runtimeOptions.getApiKey;
		this.onPayload = runtimeOptions.onPayload;
		this.onResponse = runtimeOptions.onResponse;
		this.beforeToolCall = runtimeOptions.beforeToolCall;
		this.afterToolCall = runtimeOptions.afterToolCall;
		this.shouldStopAfterTurn = runtimeOptions.shouldStopAfterTurn;
		this.prepareNextTurn = runtimeOptions.prepareNextTurn;
		this.prepareNextTurnWithContext = runtimeOptions.prepareNextTurnWithContext;
		this.steeringQueue = new PendingMessageQueue(runtimeOptions.steeringMode ?? "one-at-a-time");
		this.followUpQueue = new PendingMessageQueue(runtimeOptions.followUpMode ?? "one-at-a-time");
		this.sessionId = runtimeOptions.sessionId;
		this.thinkingBudgets = runtimeOptions.thinkingBudgets;
		this.transport = runtimeOptions.transport ?? "auto";
		this.maxRetryDelayMs = runtimeOptions.maxRetryDelayMs;
		this.toolExecution = runtimeOptions.toolExecution ?? "parallel";
		this.eventInstrumentation = runtimeOptions.eventInstrumentation;
		this.eventDelivery = new AgentEventDeliveryDispatcher(this, runtimeOptions.onEventDeliveryDiagnostic);
	}

	/**
	 * Subscribe to agent lifecycle events.
	 *
	 * Listener promises are awaited in subscription order and are included in
	 * the current run's settlement. Listeners also receive the active abort
	 * signal for the current run.
	 *
	 * `agent_end` is the final emitted event for a run, but the agent does not
	 * become idle until all awaited listeners for that event have settled.
	 */
	subscribe(
		listener: (event: AgentEvent, signal: AbortSignal) => Promise<void> | void,
		options: Omit<EventSubscriptionOptions<AgentEvent>, "delivery"> = {},
	): () => void {
		return this.eventDelivery.subscribe((event) => listener(event, this.requireActiveSignal()), {
			...options,
			delivery: "critical",
		});
	}

	/** Subscribe a display-only observer to coalesced latest updates. */
	subscribeObserver(
		listener: (event: AgentEvent, signal: AbortSignal) => Promise<void> | void,
		options: Omit<EventSubscriptionOptions<AgentEvent>, "delivery"> = {},
	): () => void {
		return this.eventDelivery.subscribe((event) => listener(event, this.requireActiveSignal()), {
			...options,
			delivery: "latest",
		});
	}

	get eventDeliveryStats(): EventDeliveryStats {
		return this.eventDelivery.stats;
	}

	/**
	 * Current agent state.
	 *
	 * Assigning `state.tools` or `state.messages` copies the provided top-level array.
	 */
	get state(): AgentState {
		return this._state;
	}

	/** Controls how queued steering messages are drained. */
	set steeringMode(mode: QueueMode) {
		this.steeringQueue.mode = mode;
	}

	get steeringMode(): QueueMode {
		return this.steeringQueue.mode;
	}

	/** Controls how queued follow-up messages are drained. */
	set followUpMode(mode: QueueMode) {
		this.followUpQueue.mode = mode;
	}

	get followUpMode(): QueueMode {
		return this.followUpQueue.mode;
	}

	/** Queue a message to be injected after the current assistant turn finishes. */
	steer(message: AgentMessage): void {
		this.steeringQueue.enqueue(message);
	}

	/** Queue a message to run only after the agent would otherwise stop. */
	followUp(message: AgentMessage): void {
		this.followUpQueue.enqueue(message);
	}

	/** Remove all queued steering messages. */
	clearSteeringQueue(): void {
		this.steeringQueue.clear();
	}

	/** Remove all queued follow-up messages. */
	clearFollowUpQueue(): void {
		this.followUpQueue.clear();
	}

	/** Remove all queued steering and follow-up messages. */
	clearAllQueues(): void {
		this.clearSteeringQueue();
		this.clearFollowUpQueue();
	}

	/** Returns true when either queue still contains pending messages. */
	hasQueuedMessages(): boolean {
		return this.steeringQueue.hasItems() || this.followUpQueue.hasItems();
	}

	/** Active abort signal for the current run, if any. */
	get signal(): AbortSignal | undefined {
		return this.activeRun?.abortController.signal;
	}

	/** Explicit cancellation of the current or most recently admitted run. */
	get abortRequested(): boolean {
		return this._abortRequested;
	}

	/** Abort the current run, if one is active. */
	abort(): void {
		if (!this.activeRun) return;
		this._abortRequested = true;
		abortRun(this.activeRun.abortController);
	}

	/**
	 * Resolve when the current run and all awaited event listeners have finished.
	 *
	 * This resolves after `agent_end` listeners settle.
	 */
	waitForIdle(): Promise<void> {
		return this.activeRun?.promise ?? Promise.resolve();
	}

	/** Clear transcript state, runtime state, and queued messages. */
	reset(): void {
		if (this.activeRun) {
			throw new Error("Agent is already processing. Wait for completion before resetting.");
		}

		this._abortRequested = false;
		this._state.messages = [];
		this._state.isStreaming = false;
		this._state.streamingMessage = undefined;
		this._state.pendingToolCalls = new Set<string>();
		this._state.errorMessage = undefined;
		this.clearFollowUpQueue();
		this.clearSteeringQueue();
	}

	/** Start a new prompt from text, a single message, or a batch of messages. */
	async prompt(message: AgentMessage | AgentMessage[], onAccepted?: () => void): Promise<void>;
	async prompt(input: string, images?: ImageContent[]): Promise<void>;
	async prompt(input: string | AgentMessage | AgentMessage[], imagesOrAccepted?: ImageContent[] | (() => void)): Promise<void> {
		if (this.activeRun) {
			throw new Error(
				"Agent is already processing a prompt. Use steer() or followUp() to queue messages, or wait for completion.",
			);
		}
		const messages = this.normalizePromptInput(input, typeof imagesOrAccepted === "function" ? undefined : imagesOrAccepted);
		await this.runPromptMessages(messages, { onAccepted: typeof imagesOrAccepted === "function" ? imagesOrAccepted : undefined });
	}

	/** Continue the transcript; settlement may consume queued messages before a new model request. */
	async continue(consumeQueued = false): Promise<void> {
		if (this.activeRun) {
			throw new Error("Agent is already processing. Wait for completion before continuing.");
		}

		const lastMessage = this._state.messages[this._state.messages.length - 1];
		if (!lastMessage) {
			throw new Error("No messages to continue from");
		}

		if (consumeQueued || lastMessage.role === "assistant") {
			const queuedSteering = this.steeringQueue.drain();
			if (queuedSteering.length > 0) {
				await this.runPromptMessages(queuedSteering, { skipInitialSteeringPoll: true });
				return;
			}

			const queuedFollowUps = this.followUpQueue.drain();
			if (queuedFollowUps.length > 0) {
				await this.runPromptMessages(queuedFollowUps);
				return;
			}

			if (lastMessage.role === "assistant") throw new Error("Cannot continue from message role: assistant");
		}

		await this.runContinuation();
	}

	private normalizePromptInput(
		input: string | AgentMessage | AgentMessage[],
		images?: ImageContent[],
	): AgentMessage[] {
		if (Array.isArray(input)) {
			return input;
		}

		if (typeof input !== "string") {
			return [input];
		}

		const content: Array<TextContent | ImageContent> = [{ type: "text", text: input }];
		if (images && images.length > 0) {
			content.push(...images);
		}
		return [{ role: "user", content, timestamp: Date.now() }];
	}

	private async runPromptMessages(
		messages: AgentMessage[],
		options: { skipInitialSteeringPoll?: boolean; onAccepted?: () => void } = {},
	): Promise<void> {
		await this.runWithLifecycle(async (signal) => {
			await runAgentLoop(
				messages,
				this.createContextSnapshot(),
				this.createLoopConfig(options),
				(event) => this.processEvents(event),
				signal,
				this.streamFunction,
			);
		}, false, options.onAccepted);
	}

	private async runContinuation(): Promise<void> {
		await this.runWithLifecycle(async (signal) => {
			await runAgentLoopContinue(
				this.createContextSnapshot(),
				this.createLoopConfig(),
				(event) => this.processEvents(event),
				signal,
				this.streamFunction,
			);
		});
	}

	private createContextSnapshot(): AgentContext {
		return {
			systemPrompt: this._state.systemPrompt,
			messages: this._state.messages.slice(),
			tools: this._state.tools.slice(),
			modelTools: this._state.modelTools,
		};
	}

	private createLoopConfig(options: { skipInitialSteeringPoll?: boolean } = {}): AgentLoopConfig {
		let skipInitialSteeringPoll = options.skipInitialSteeringPoll === true;
		const shouldStopAfterTurn = this.shouldStopAfterTurn;
		return {
			model: this._state.model,
			reasoning: this._state.thinkingLevel === "off" ? undefined : this._state.thinkingLevel,
			sessionId: this.sessionId,
			onPayload: this.onPayload,
			onResponse: this.onResponse,
			transport: this.transport,
			thinkingBudgets: this.thinkingBudgets,
			maxRetryDelayMs: this.maxRetryDelayMs,
			toolExecution: this.toolExecution,
			getCurrentTools: this.getCurrentTools,
			eventInstrumentation: this.eventInstrumentation,
			beforeToolCall: this.beforeToolCall,
			afterToolCall: this.afterToolCall,
			shouldStopAfterTurn: shouldStopAfterTurn
				? async (context) => await shouldStopAfterTurn(context, this.signal)
				: undefined,
			prepareNextTurn:
				this.prepareNextTurnWithContext || this.prepareNextTurn
					? async (context) => {
							if (this.prepareNextTurnWithContext) {
								return await this.prepareNextTurnWithContext(context, this.signal);
							}
							return await this.prepareNextTurn?.(this.signal);
						}
					: undefined,
			convertToLlm: this.convertToLlm,
			transformContext: this.transformContext,
			getApiKey: this.getApiKey,
			getSteeringMessages: async () => {
				if (skipInitialSteeringPoll) {
					skipInitialSteeringPoll = false;
					return [];
				}
				return this.steeringQueue.drain();
			},
			getFollowUpMessages: async () => this.followUpQueue.drain(),
		};
	}

	/** @internal Experimental host-only dispatch; failures propagate without model retry messages. */
	async dispatchHostTool(call: AgentToolCall, complete?: () => Promise<AgentMessage | undefined>): Promise<ToolResultMessage> {
		let result!: ToolResultMessage;
		await this.runWithLifecycle(async signal => {
			const publishNotice = complete ? async () => {
				const notice = await complete();
				if (!notice) return;
				this._state.messages.push(notice);
				await this.processEvents({ type: "message_start", message: { ...notice } }, false);
				await this.processEvents({ type: "message_end", message: { ...notice } }, false);
			} : undefined;
			result = await runHostToolDispatch(call, { systemPrompt: this._state.systemPrompt, messages: this._state.messages.slice(), tools: this._state.tools.slice() },
				this.createLoopConfig(), event => this.processEvents(event, false), signal, publishNotice);
		}, true);
		return result;
	}

	private async runWithLifecycle(executor: (signal: AbortSignal) => Promise<void>, hostOnly = false, onAccepted?: () => void): Promise<void> {
		if (this.activeRun) {
			throw new Error("Agent is already processing.");
		}

		const abortController = new AbortController();
		let resolvePromise = () => {};
		const promise = new Promise<void>((resolve) => {
			resolvePromise = resolve;
		});
		this.activeRun = { promise, resolve: resolvePromise, abortController };
		this._abortRequested = false;

		this._state.isStreaming = true;
		this._state.streamingMessage = undefined;
		this._state.errorMessage = undefined;

		try {
			onAccepted?.();
			await executor(abortController.signal);
		} catch (error) {
			const aborted = abortController.signal.aborted;
			// A failed consumer can abandon a still-running provider producer.
			abortRun(abortController);
			if (hostOnly) throw error;
			await this.handleRunFailure(error, aborted);
		} finally {
			this.finishRun();
		}
	}

	private async handleRunFailure(error: unknown, aborted: boolean): Promise<void> {
		const failureMessage = {
			role: "assistant",
			content: [{ type: "text", text: "" }],
			api: this._state.model.api,
			provider: this._state.model.provider,
			model: this._state.model.id,
			usage: EMPTY_USAGE,
			stopReason: aborted ? "aborted" : "error",
			errorMessage: error instanceof Error ? error.message : String(error),
			timestamp: Date.now(),
		} satisfies AgentMessage;
		await this.processEvents({ type: "message_start", message: failureMessage });
		await this.processEvents({ type: "message_end", message: failureMessage });
		await this.processEvents({ type: "turn_end", message: failureMessage, toolResults: [] });
		await this.processEvents({ type: "agent_end", messages: [failureMessage] });
	}

	private finishRun(): void {
		this._state.isStreaming = false;
		this._state.streamingMessage = undefined;
		this._state.pendingToolCalls = new Set<string>();
		this.clearPendingMessageUpdate();
		this.activeRun?.resolve();
		this.activeRun = undefined;
	}

	/**
	 * Reduce internal state for a loop event, then await listeners.
	 *
	 * `agent_end` only means no further loop events will be emitted. The run is
	 * considered idle later, after all awaited listeners for `agent_end` finish
	 * and `finishRun()` clears runtime-owned state.
	 */
	private async processEvents(event: AgentEvent, admitMessage = true): Promise<void> {
		switch (event.type) {
			case "message_start":
				this._state.streamingMessage = event.message;
				break;

			case "message_update":
				this._state.streamingMessage = event.message;
				break;

			case "message_end":
				this._state.streamingMessage = undefined;
				if (admitMessage) this._state.messages.push(event.message);
				break;

			case "tool_execution_start": {
				const pendingToolCalls = new Set(this._state.pendingToolCalls);
				pendingToolCalls.add(event.toolCallId);
				this._state.pendingToolCalls = pendingToolCalls;
				break;
			}

			case "tool_execution_end": {
				const pendingToolCalls = new Set(this._state.pendingToolCalls);
				pendingToolCalls.delete(event.toolCallId);
				this._state.pendingToolCalls = pendingToolCalls;
				break;
			}

			case "turn_end":
				if (event.message.role === "assistant" && event.message.errorMessage) {
					this._state.errorMessage = event.message.errorMessage;
				}
				break;

			case "agent_end":
				this._state.streamingMessage = undefined;
				break;
		}

		const latestKey = this.getLatestEventKey(event);
		if (latestKey !== undefined) {
			if (this.eventDelivery.hasAwaitedListeners(event)) {
				await this.eventDelivery.publishAwaited(this.snapshotAwaitedEvent(event));
			}
			if (event.type === "message_update") {
				if (this.eventDelivery.hasLatestListeners) {
					this.eventDelivery.publishLatest(latestKey, this.prepareMessageUpdate(event));
				} else {
					this.clearPendingMessageUpdate();
				}
			} else {
				this.eventDelivery.publishLatest(latestKey, event);
			}
			return;
		}
		await this.eventDelivery.publishCritical(event);
	}

	private requireActiveSignal(): AbortSignal {
		const signal = this.activeRun?.abortController.signal;
		if (!signal) throw new Error("Agent listener invoked outside active run");
		return signal;
	}

	private getLatestEventKey(event: AgentEvent): string | undefined {
		if (event.type === "message_update") return "message";
		if (event.type === "tool_execution_update") return `tool:${event.toolCallId}`;
		return undefined;
	}

	private prepareMessageUpdate(event: MessageUpdateEvent): PendingMessageUpdateEvent {
		let pending = this.pendingMessageUpdateEvent;
		if (pending === undefined) {
			pending = {
				type: "message_update",
				message: event.message,
				assistantMessageEvent: event.assistantMessageEvent,
				changedToolUpdates: [],
			};
			this.pendingMessageUpdateEvent = pending;
		} else {
			pending.message = event.message;
			pending.assistantMessageEvent = event.assistantMessageEvent;
		}

		const assistantUpdate = event.assistantMessageEvent;
		if (
			assistantUpdate.type !== "toolcall_start" &&
			assistantUpdate.type !== "toolcall_delta" &&
			assistantUpdate.type !== "toolcall_end"
		) return pending;
		const phase = getToolUpdatePhase(assistantUpdate);
		const contentIndex = assistantUpdate.contentIndex;
		const content = assistantUpdate.partial.content[contentIndex];
		if (content?.type !== "toolCall") return pending;
		const generation = getToolUpdateGeneration(content, assistantUpdate);
		let record = this.pendingChangedToolUpdates.get(content.id);
		if (record === undefined) {
			record = {
				toolCallId: content.id,
				contentIndex,
				phase,
				generation,
				finalized: phase === "end",
			};
			this.pendingChangedToolUpdates.set(content.id, record);
			pending.changedToolUpdates.push(record);
			this.eventInstrumentation?.onPendingToolMetadata?.(this.pendingChangedToolUpdates.size);
			return pending;
		}

		record.contentIndex = contentIndex;
		if (record.finalized) return pending;
		record.phase = phase;
		if (generation !== undefined) record.generation = generation;
		if (phase === "end") record.finalized = true;
		return pending;
	}

	private clearPendingMessageUpdate(): void {
		if (this.pendingMessageUpdateEvent === undefined && this.pendingChangedToolUpdates.size === 0) return;
		this.pendingMessageUpdateEvent = undefined;
		this.pendingChangedToolUpdates.clear();
		this.eventInstrumentation?.onPendingToolMetadata?.(0);
	}

	private snapshotAwaitedEvent(event: AgentEvent): AgentEvent {
		if (event.type !== "message_update") return event;
		const message = { ...event.message };
		const assistantMessageEvent = {
			...event.assistantMessageEvent,
			partial: message as AssistantMessage,
		} as AssistantMessageEvent;
		return { ...event, message, assistantMessageEvent };
	}

	/** @internal EventDeliveryDispatcher ownership hook. */
	snapshotObserverEvent(event: AgentEvent): AgentEvent {
		if (event.type === "message_update") this.eventInstrumentation?.onAssistantSnapshot?.();
		const snapshot = structuredClone(event);
		deepFreezeSnapshot(snapshot);
		return snapshot;
	}

	/** @internal EventDeliveryDispatcher ownership hook. */
	releaseObserverEvent(key: string, event: AgentEvent): void {
		if (key === "message" && event === this.pendingMessageUpdateEvent) this.clearPendingMessageUpdate();
	}
}
