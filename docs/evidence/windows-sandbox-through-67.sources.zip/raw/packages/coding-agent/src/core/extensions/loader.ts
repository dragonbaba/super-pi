/**
 * Extension loader - loads TypeScript extension modules using jiti.
 *
 */

import * as fs from "node:fs";
import { createRequire } from "node:module";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import type { Provider } from "@super-pi/ai";
import { createOpenAICodexTransportOwner } from "@super-pi/ai/api/openai-codex-responses";
import type { KeyId } from "@super-pi/tui";
import { CONFIG_DIR_NAME, getAgentDir, isBunBinary } from "../../config.ts";
import { resolvePath } from "../../utils/paths.ts";
import { createEventBus, type EventBus } from "../event-bus.ts";
import { SessionExecutionBoundary } from "../execution-boundary.ts";
import type { ExecOptions } from "../exec.ts";
import { execCommand } from "../exec.ts";
import { readPiManifest } from "../pi-manifest.ts";
import { compareCanonicalIdentifiers } from "../prefix-manifest.ts";
import { createSyntheticSourceInfo } from "../source-info.ts";
import { time } from "../timings.ts";
import type {
	EntryRenderer,
	Extension,
	ExtensionAPI,
	ExtensionFactory,
	ExtensionObserverOptions,
	ExtensionRuntime,
	CompactionStrategy,
	LoadExtensionsResult,
	MarkdownTransformer,
	MessageRenderer,
	ProviderConfig,
	RegisteredCommand,
	ToolDefinition,
	ToolRendererResolver,
} from "./types.ts";

type CreateJiti = typeof import("jiti/static")["createJiti"];
let createJitiPromise: Promise<CreateJiti> | undefined;

function loadCreateJiti(): Promise<CreateJiti> {
	createJitiPromise ??= import("jiti/static").then((module) => module.createJiti);
	return createJitiPromise;
}

const require = createRequire(import.meta.url);

const isTypeScriptSourceRuntime = !isBunBinary && path.extname(fileURLToPath(import.meta.url)) === ".ts";

/**
 * Get aliases for jiti (used in built Node.js mode).
 * In Bun binary mode, virtualModules is used instead.
 */
let _aliases: Record<string, string> | null = null;

function getAliases(): Record<string, string> {
	if (_aliases) return _aliases;

	const __dirname = path.dirname(fileURLToPath(import.meta.url));
	const packageIndex = path.resolve(__dirname, "../..", "index.js");

	const typeboxEntry = require.resolve("typebox");
	const typeboxCompileEntry = require.resolve("typebox/compile");
	const typeboxValueEntry = require.resolve("typebox/value");

	const packagesRoot = path.resolve(__dirname, "../../../../");
	const resolveWorkspaceOrImport = (workspaceRelativePath: string, specifier: string): string => {
		const workspacePath = path.join(packagesRoot, workspaceRelativePath);
		if (fs.existsSync(workspacePath)) {
			return workspacePath;
		}
		return fileURLToPath(import.meta.resolve(specifier));
	};

	const piCodingAgentEntry = packageIndex;
	const piAgentCoreEntry = resolveWorkspaceOrImport("agent/dist/index.js", "@super-pi/agent-core");
	const piTuiEntry = resolveWorkspaceOrImport("tui/dist/index.js", "@super-pi/tui");
	// Extensions resolve the pi-ai root to the compat entrypoint (a strict
	// superset of the core entrypoint): existing extensions using the old
	// global API keep working at runtime until compat is removed.
	const piAiCompatEntry = resolveWorkspaceOrImport("ai/dist/compat.js", "@super-pi/ai/compat");
	const piAiOauthEntry = resolveWorkspaceOrImport("ai/dist/oauth.js", "@super-pi/ai/oauth");
	const piAiProvidersEntry = resolveWorkspaceOrImport(
		"ai/dist/providers/all.js",
		"@super-pi/ai/providers/all",
	);

	_aliases = {
		"@super-pi/coding-agent/internal/session-lease": path.resolve(__dirname, "../session-lease"),
		"@super-pi/coding-agent/internal/files": path.resolve(__dirname, "../files"),
		"@super-pi/coding-agent/internal/tasks": path.resolve(__dirname, "../tasks"),
		"@super-pi/ai/api/openai-codex-responses": resolveWorkspaceOrImport(
			"ai/dist/api/openai-codex-responses.js", "@super-pi/ai/api/openai-codex-responses",
		),
		"@super-pi/coding-agent": piCodingAgentEntry,
		"@super-pi/agent-core": piAgentCoreEntry,
		"@super-pi/tui": piTuiEntry,
		"@super-pi/ai/providers/all": piAiProvidersEntry,
		"@super-pi/ai/compat": piAiCompatEntry,
		"@super-pi/ai/oauth": piAiOauthEntry,
		"@super-pi/ai": piAiCompatEntry,
		"@mariozechner/pi-coding-agent": piCodingAgentEntry,
		"@mariozechner/pi-agent-core": piAgentCoreEntry,
		"@mariozechner/pi-tui": piTuiEntry,
		"@mariozechner/pi-ai/providers/all": piAiProvidersEntry,
		"@mariozechner/pi-ai/compat": piAiCompatEntry,
		"@mariozechner/pi-ai/oauth": piAiOauthEntry,
		"@mariozechner/pi-ai": piAiCompatEntry,
		typebox: typeboxEntry,
		"typebox/compile": typeboxCompileEntry,
		"typebox/value": typeboxValueEntry,
		"@sinclair/typebox": typeboxEntry,
		"@sinclair/typebox/compile": typeboxCompileEntry,
		"@sinclair/typebox/value": typeboxValueEntry,
	};

	return _aliases;
}

type HandlerFn = (...args: unknown[]) => Promise<unknown> | unknown;

type PendingRuntimeChange =
	| { type: "registerProvider"; name: string; config: ProviderConfig }
	| { type: "registerNativeProvider"; provider: Provider }
	| { type: "unregisterProvider"; name: string };

let extensionCacheCwd: string | undefined;
let extensionCacheGeneration = 0;
const extensionCache = new Map<string, ExtensionFactory>();
let virtualModulesPromise: Promise<Record<string, unknown>> | undefined;

function loadVirtualModules(): Promise<Record<string, unknown>> {
	virtualModulesPromise ??= import("./virtual-modules.ts").then((module) => module.VIRTUAL_MODULES);
	return virtualModulesPromise;
}

interface ExtensionCacheToken {
	cwd: string;
	generation: number;
}

export function clearExtensionCache(): void {
	extensionCache.clear();
	extensionCacheCwd = undefined;
	extensionCacheGeneration++;
}

function useExtensionCacheCwd(cwd: string): ExtensionCacheToken {
	const resolvedCwd = resolvePath(cwd);
	if (extensionCacheCwd !== undefined && extensionCacheCwd !== resolvedCwd) {
		clearExtensionCache();
	}
	extensionCacheCwd = resolvedCwd;
	return { cwd: resolvedCwd, generation: extensionCacheGeneration };
}

function ignoreRuntimeDisposalRejection(): void {} // Awaited session shutdown/reload reports cleanup failures.

/**
 * Create a runtime with throwing stubs for action methods.
 * Runner.bindCore() replaces these with real implementations.
 */
export function createExtensionRuntime(): ExtensionRuntime {
	const notInitialized = () => {
		throw new Error("Extension runtime not initialized. Action methods cannot be called during extension loading.");
	};
	const state: { staleMessage?: string } = {};
	const eventBusUnsubscribers = new Set<() => void>();
	const assertActive = () => {
		if (state.staleMessage) {
			throw new Error(state.staleMessage);
		}
	};

	const codexOwner = createOpenAICodexTransportOwner();
	const runtime: ExtensionRuntime = {
		compactionStrategies: new Map(),
		executionBoundary: new SessionExecutionBoundary(),
		codexRemoteCompactionEnabled: false,
		openAIResponsesDispatch: undefined,
		codexDispatch: { owner: codexOwner, assertCurrent() { assertActive(); runtime.executionBoundary.assertCurrent(); } },
		openAIResponsesOwner: undefined,
		providerOwnerDisposal: undefined,
		disposeProviderOwners: () => {
			if (runtime.providerOwnerDisposal) return runtime.providerOwnerDisposal;
			runtime.openAIResponsesDispatch = undefined;
			const owners = runtime.openAIResponsesOwner ? [codexOwner, runtime.openAIResponsesOwner] : [codexOwner];
			let revokeError: unknown;
			let revokeFailed = false;
			let deadline: ReturnType<typeof setTimeout> | undefined;
			const cleanup = Promise.resolve().then(async () => {
				const pending: Promise<void>[] = [];
				for (const owner of owners) {
					try { pending.push(Promise.resolve(owner.dispose())); } catch (error) { pending.push(Promise.reject(error)); }
				}
				const results = await Promise.allSettled(pending);
				if (revokeFailed) throw revokeError;
				for (const result of results) if (result.status === "rejected") throw result.reason;
			});
			const timeout = new Promise<never>((_resolve, reject) => {
				deadline = setTimeout(() => reject(new Error("Provider owner cleanup timed out; shutdown remains unconfirmed")), 10_000);
			});
			runtime.providerOwnerDisposal = Promise.race([cleanup, timeout]).finally(() => clearTimeout(deadline));
			// Publish the join operation before synchronous abort observers can reenter.
			for (const owner of owners) {
				try { owner.revoke(); } catch (error) { if (!revokeFailed) { revokeFailed = true; revokeError = error; } }
			}
			return runtime.providerOwnerDisposal;
		},
		sendMessage: notInitialized,
		sendUserMessage: notInitialized,
		appendEntry: notInitialized,
		setSessionName: notInitialized,
		getSessionName: notInitialized,
		setLabel: notInitialized,
		getActiveTools: notInitialized,
		getAllTools: notInitialized,
		buildProviderRequestPayload: () => Promise.reject(new Error("Extension runtime not initialized")),
		withSupplementalSummary: () => Promise.reject(new Error("Extension runtime not initialized")),
		compactProviderRequestPayload: () => Promise.reject(new Error("Extension runtime not initialized")),
		setActiveTools: notInitialized,
		// registerTool() is valid during extension load; refresh is only needed post-bind.
		refreshTools: () => {},
		getCommands: notInitialized,
		setModel: () => Promise.reject(new Error("Extension runtime not initialized")),
		getThinkingLevel: notInitialized,
		setThinkingLevel: notInitialized,
		flagValues: new Map(),
		pendingProviderRegistrations: [],
		pendingNativeProviderRegistrations: [],
		assertActive,
		invalidate: (message, ownersCleanupStarted = false) => {
			if (state.staleMessage) return;
			runtime.compactionStrategies.clear();
			runtime.codexRemoteCompactionEnabled = false;
			runtime.openAIResponsesDispatch = undefined;
			if (!ownersCleanupStarted) {
				void runtime.disposeProviderOwners().catch(ignoreRuntimeDisposalRejection);
				void runtime.executionBoundary.dispose().catch(ignoreRuntimeDisposalRejection);
				void runtime.nativeTasks?.dispose().catch(ignoreRuntimeDisposalRejection);
				void runtime.nativeFiles?.dispose().catch(ignoreRuntimeDisposalRejection);
			}
			state.staleMessage =
				message ??
				"This extension ctx is stale after session replacement or reload. Do not use a captured pi or command ctx after ctx.newSession(), ctx.fork(), ctx.switchSession(), or ctx.reload(). For newSession, fork, and switchSession, move post-replacement work into withSession and use the ctx passed to withSession. For reload, do not use the old ctx after await ctx.reload().";
			for (const unsubscribe of eventBusUnsubscribers) unsubscribe();
			eventBusUnsubscribers.clear();
		},
		trackEventBusSubscription: (unsubscribe) => {
			let active = true;
			const trackedUnsubscribe = () => {
				if (!active) return;
				active = false;
				eventBusUnsubscribers.delete(trackedUnsubscribe);
				unsubscribe();
			};
			eventBusUnsubscribers.add(trackedUnsubscribe);
			return trackedUnsubscribe;
		},
		// Pre-bind: queue registrations so bindCore() can flush them once the
		// model registry is available. bindCore() replaces both with direct calls.
		registerProvider: (name, config, extensionPath = "<unknown>") => {
			runtime.pendingProviderRegistrations.push({ name, config, extensionPath });
		},
		registerNativeProvider: (provider, extensionPath = "<unknown>") => {
			runtime.pendingNativeProviderRegistrations.push({ provider, extensionPath });
		},
		unregisterProvider: (name) => {
			let writeIndex = 0;
			for (const registration of runtime.pendingProviderRegistrations) {
				if (registration.name === name) continue;
				runtime.pendingProviderRegistrations[writeIndex++] = registration;
			}
			runtime.pendingProviderRegistrations.length = writeIndex;
			writeIndex = 0;
			for (const registration of runtime.pendingNativeProviderRegistrations) {
				if (registration.provider.id === name) continue;
				runtime.pendingNativeProviderRegistrations[writeIndex++] = registration;
			}
			runtime.pendingNativeProviderRegistrations.length = writeIndex;
		},
	};

	runtime.executionBoundary.register("provider:openai-codex", codexOwner);
	return runtime;
}

/**
 * Create the ExtensionAPI for an extension.
 * Registration methods write to the extension object.
 * Action methods delegate to the shared runtime.
 */
function createExtensionAPI(
	extension: Extension,
	runtime: ExtensionRuntime,
	cwd: string,
	eventBus: EventBus,
): { api: ExtensionAPI; commit: () => void; discard: () => void } {
	const finiteNonNegative = (name: string, value: number): number => {
		if (!Number.isFinite(value) || value < 0) {
			throw new RangeError(`${name} must be a finite non-negative number`);
		}
		return value;
	};
	const finitePositive = (name: string, value: number): number => {
		if (!Number.isFinite(value) || value <= 0) {
			throw new RangeError(`${name} must be a finite positive number`);
		}
		return value;
	};
	const finitePositiveInteger = (name: string, value: number): number => {
		if (!Number.isSafeInteger(value) || value <= 0) {
			throw new RangeError(`${name} must be a finite positive integer`);
		}
		return value;
	};
	const pendingFlagValues = new Map<string, boolean | string>();
	const pendingRuntimeChanges: PendingRuntimeChange[] = [];
	const loadingUnsubscribers: Array<() => void> = [];
	let state: "loading" | "active" | "failed" = "loading";
	const assertActive = () => {
		if (state === "failed") {
			throw new Error(`Extension "${extension.path}" failed to load and its API is no longer active.`);
		}
		runtime.assertActive();
	};
	const applyRuntimeChange = (change: PendingRuntimeChange) => {
		if (state === "loading") {
			pendingRuntimeChanges.push(change);
			return;
		}
		applyPendingRuntimeChange(runtime, extension.path, change);
	};
	const clearPending = () => {
		pendingFlagValues.clear();
		pendingRuntimeChanges.length = 0;
		loadingUnsubscribers.length = 0;
	};

	const api = {
		// Registration methods - write to extension
		registerCompactionStrategy(strategy: CompactionStrategy): void {
			assertActive();
			if (state !== "loading") throw new Error("Compaction strategies must be registered during extension loading");
			if (!strategy || typeof strategy.id !== "string" || !/^[a-z0-9][a-z0-9._-]{0,79}$/.test(strategy.id) || typeof strategy.prepare !== "function") {
				throw new TypeError("Invalid compaction strategy");
			}
			if (runtime.compactionStrategies.has(strategy.id)) throw new Error(`Duplicate compaction strategy: ${strategy.id}`);
			if (runtime.compactionStrategies.size >= 16) throw new Error("At most 16 compaction strategies may be registered");
			const registered = { id: strategy.id, prepare: strategy.prepare, extensionPath: extension.path };
			runtime.compactionStrategies.set(registered.id, registered);
			loadingUnsubscribers.push(() => {
				if (runtime.compactionStrategies.get(registered.id) === registered) runtime.compactionStrategies.delete(registered.id);
			});
		},
		on(event: string, handler: HandlerFn, options?: { phase: "image-processing" }): void {
			assertActive();
			if (event === "input" && options?.phase === "image-processing") event = "input:image-processing";
			const list = extension.handlers.get(event) ?? [];
			list.push(handler);
			extension.handlers.set(event, list);
		},

		observe(event: string, handler: HandlerFn, options: ExtensionObserverOptions = {}): void {
			assertActive();
			const list = extension.observers.get(event) ?? [];
			list.push({
				handler,
				slowThresholdMs: finiteNonNegative("slowThresholdMs", options.slowThresholdMs ?? 100),
				timeoutMs: finitePositive("timeoutMs", options.timeoutMs ?? 1_000),
				disableAfterErrors: finitePositiveInteger("disableAfterErrors", options.disableAfterErrors ?? 3),
				consecutiveErrors: 0,
				disabled: false,
			});
			extension.observers.set(event, list);
		},

		registerTool(tool: ToolDefinition): void {
			assertActive();
			extension.tools.set(tool.name, {
				definition: tool,
				sourceInfo: extension.sourceInfo,
			});
			runtime.refreshTools();
		},

		registerToolRenderer(resolver: ToolRendererResolver): void {
			assertActive();
			if (typeof resolver !== "function") throw new TypeError("registerToolRenderer requires a synchronous resolver function");
			const resolvers = extension.toolRenderers ??= [];
			if (resolvers.length >= 64) throw new RangeError("An extension may register at most 64 tool renderer resolvers");
			resolvers.push(resolver);
		},

		registerCommand(name: string, options: Omit<RegisteredCommand, "name" | "sourceInfo">): void {
			assertActive();
			if (typeof name !== "string" || name.length === 0) {
				throw new Error(
					`Command registered by extension "${extension.path}" must have a non-empty string name. Use pi.registerCommand("name", { description, handler }).`,
				);
			}
			const handler = options?.handler;
			if (typeof handler !== "function") {
				throw new Error(`Command "/${name}" registered by extension "${extension.path}" must define handler().`);
			}
			extension.commands.set(name, {
				...options,
				name,
				sourceInfo: extension.sourceInfo,
				handler,
			});
		},

		registerShortcut(
			shortcut: KeyId,
			options: {
				description?: string;
				handler: (ctx: import("./types.ts").ExtensionContext) => Promise<void> | void;
			},
		): void {
			assertActive();
			extension.shortcuts.set(shortcut, { shortcut, extensionPath: extension.path, ...options });
		},

		registerFlag(
			name: string,
			options: { description?: string; type: "boolean" | "string"; default?: boolean | string },
		): void {
			assertActive();
			if (options.default !== undefined && typeof options.default !== options.type) {
				throw new Error(
					`Invalid default for flag "${name}": expected ${options.type}, got ${typeof options.default}`,
				);
			}
			extension.flags.set(name, { name, extensionPath: extension.path, ...options });
			if (options.default !== undefined && !runtime.flagValues.has(name)) {
				if (state === "loading") {
					if (!pendingFlagValues.has(name)) pendingFlagValues.set(name, options.default);
				} else {
					runtime.flagValues.set(name, options.default);
				}
			}
		},

		registerMessageRenderer<T>(customType: string, renderer: MessageRenderer<T>): void {
			assertActive();
			extension.messageRenderers.set(customType, renderer as MessageRenderer);
		},

		registerMarkdownTransformer(transformer: MarkdownTransformer): void {
			assertActive();
			extension.markdownTransformer = transformer;
		},

		registerEntryRenderer<T>(customType: string, renderer: EntryRenderer<T>): void {
			assertActive();
			extension.entryRenderers ??= new Map();
			extension.entryRenderers.set(customType, renderer as EntryRenderer);
		},

		// Flag access - checks extension registered it, reads from runtime
		getFlag(name: string): boolean | string | undefined {
			assertActive();
			if (!extension.flags.has(name)) return undefined;
			return runtime.flagValues.has(name) ? runtime.flagValues.get(name) : pendingFlagValues.get(name);
		},

		// Action methods - delegate to shared runtime
		sendMessage(message, options): void {
			assertActive();
			runtime.sendMessage(message, options);
		},

		sendUserMessage(content, options): void {
			assertActive();
			runtime.sendUserMessage(content, options);
		},

		appendEntry(customType: string, data?: unknown): void {
			assertActive();
			runtime.appendEntry(customType, data);
		},

		setSessionName(name: string): void {
			assertActive();
			runtime.setSessionName(name);
		},

		getSessionName(): string | undefined {
			assertActive();
			return runtime.getSessionName();
		},

		setLabel(entryId: string, label: string | undefined): void {
			assertActive();
			runtime.setLabel(entryId, label);
		},

		exec(command: string, args: string[], options?: ExecOptions) {
			assertActive();
			return execCommand(command, args, options?.cwd ?? cwd, options);
		},

		getActiveTools(): string[] {
			assertActive();
			return runtime.getActiveTools();
		},

		getAllTools() {
			assertActive();
			return runtime.getAllTools();
		},

		getToolCatalog() {
			assertActive();
			return runtime.getToolCatalog?.() ?? { tools: runtime.getAllTools(), activeTools: runtime.getActiveTools() };
		},

		buildProviderRequestPayload(input) {
			assertActive();
			return runtime.buildProviderRequestPayload(input);
		},
		withSupplementalSummary(signal, run) {
			assertActive();
			if (!runtime.withSupplementalSummary) throw new Error("Supplemental summary host is unavailable");
			return runtime.withSupplementalSummary(signal, run);
		},

		setCodexRemoteCompactionEnabled(enabled: boolean): void {
			assertActive();
			if (state === "loading") throw new Error("Cannot set Codex remote compaction intent during extension loading; use session_start");
			if (typeof enabled !== "boolean") throw new TypeError("Codex remote compaction intent must be a boolean");
			runtime.codexRemoteCompactionEnabled = enabled;
		},

		resetCodexTransport(): Promise<void> {
			assertActive();
			if (state === "loading") throw new Error("Cannot reset Codex transport during extension loading");
			runtime.codexDispatch.assertCurrent();
			runtime.codexDispatch.owner.revoke();
			return runtime.codexDispatch.owner.drain();
		},

		setOpenAIResponsesStream(streamSimple, owner): void {
			assertActive();
			if (state === "loading") throw new Error("Cannot install Responses dispatch during extension loading; use session_start");
			if (streamSimple !== undefined && typeof streamSimple !== "function") throw new TypeError("Responses dispatch must be a function");
			if (runtime.providerOwnerDisposal) throw new Error("Responses owner is disposed");
			if (owner !== undefined && (!owner || typeof owner.revoke !== "function" || typeof owner.drain !== "function" || typeof owner.dispose !== "function")) throw new TypeError("Invalid Responses owner");
			if (runtime.openAIResponsesOwner && (owner !== undefined || streamSimple !== undefined) && runtime.openAIResponsesOwner !== owner) throw new Error("Responses owner cannot be replaced or omitted");
			if (owner && !runtime.openAIResponsesOwner) {
				runtime.executionBoundary.register("provider:openai-responses", owner);
				runtime.openAIResponsesOwner = owner;
			}
			if (streamSimple === undefined) { runtime.openAIResponsesDispatch = undefined; return; }
			const dispatch = {
				streamSimple,
				assertCurrent(): void {
					assertActive();
					runtime.executionBoundary.assertCurrent();
					if (runtime.openAIResponsesDispatch !== dispatch) throw new Error("Responses dispatch belongs to a stale runtime installation");
				},
			};
			runtime.openAIResponsesDispatch = dispatch;
		},

		compactProviderRequestPayload(input) {
			assertActive();
			return runtime.compactProviderRequestPayload(input);
		},

		setActiveTools(toolNames: string[]): void {
			assertActive();
			runtime.setActiveTools(toolNames);
		},

		getCommands() {
			assertActive();
			return runtime.getCommands();
		},

		setModel(model) {
			assertActive();
			return runtime.setModel(model);
		},

		getThinkingLevel() {
			assertActive();
			return runtime.getThinkingLevel();
		},

		setThinkingLevel(level) {
			assertActive();
			runtime.setThinkingLevel(level);
		},

		registerProvider(providerOrName: Provider | string, config?: ProviderConfig) {
			assertActive();
			if (typeof providerOrName === "string") {
				if (!config) throw new Error("Provider config is required when registering by name");
				applyRuntimeChange({ type: "registerProvider", name: providerOrName, config });
				return;
			}
			applyRuntimeChange({ type: "registerNativeProvider", provider: providerOrName });
		},

		unregisterProvider(name: string) {
			assertActive();
			applyRuntimeChange({ type: "unregisterProvider", name });
		},

		assertExecutionCurrent() {
			assertActive();
			runtime.executionBoundary.assertCurrent();
		},
		transitionExecution(publish) {
			assertActive();
			if (!runtime.transitionExecution) throw new Error("Native execution transitions are unavailable in this host.");
			return runtime.transitionExecution(publish);
		},
		waitForExecutionIdle() {
			assertActive();
			if (!runtime.waitForExecutionIdle) throw new Error("Native execution completion is unavailable in this host.");
			return runtime.waitForExecutionIdle();
		},

		registerExecutionOwner(name, owner) {
			assertActive();
			if (typeof name !== "string" || !name || name.length > 80) throw new Error("Invalid execution owner name");
			const unregister = runtime.executionBoundary.register(`extension:${extension.path}:${name}`, owner);
			if (state === "loading") loadingUnsubscribers.push(unregister);
			return unregister;
		},

		events: {
			emit(channel, data) {
				assertActive();
				eventBus.emit(channel, data);
			},
			on(channel, handler) {
				assertActive();
				const unsubscribe = runtime.trackEventBusSubscription(eventBus.on(channel, handler));
				if (state === "loading") loadingUnsubscribers.push(unsubscribe);
				return unsubscribe;
			},
		},
	} as ExtensionAPI;

	return {
		api,
		commit: () => {
			if (state !== "loading") return;
			runtime.assertActive();
			const providerRegistrations = runtime.pendingProviderRegistrations.slice();
			const nativeProviderRegistrations = runtime.pendingNativeProviderRegistrations.slice();
			try {
				for (const change of pendingRuntimeChanges) {
					applyPendingRuntimeChange(runtime, extension.path, change);
				}
			} catch (error) {
				// Loading normally uses an unbound runtime, whose provider methods only mutate
				// these queues. Restore their exact pre-extension state if a custom runtime throws.
				runtime.pendingProviderRegistrations = providerRegistrations;
				runtime.pendingNativeProviderRegistrations = nativeProviderRegistrations;
				throw error;
			}
			for (const [name, value] of pendingFlagValues) {
				if (!runtime.flagValues.has(name)) runtime.flagValues.set(name, value);
			}
			state = "active";
			clearPending();
		},
		discard: () => {
			if (state !== "loading") return;
			state = "failed";
			extension.toolRenderers = undefined;
			for (const unsubscribe of loadingUnsubscribers) unsubscribe();
			clearPending();
		},
	};
}

function applyPendingRuntimeChange(
	runtime: ExtensionRuntime,
	extensionPath: string,
	change: PendingRuntimeChange,
): void {
	switch (change.type) {
		case "registerProvider":
			runtime.registerProvider(change.name, change.config, extensionPath);
			break;
		case "registerNativeProvider":
			runtime.registerNativeProvider(change.provider, extensionPath);
			break;
		case "unregisterProvider":
			runtime.unregisterProvider(change.name, extensionPath);
			break;
	}
}

function isCurrentCacheToken(cacheToken: ExtensionCacheToken | undefined): cacheToken is ExtensionCacheToken {
	return (
		cacheToken !== undefined &&
		extensionCacheCwd === cacheToken.cwd &&
		extensionCacheGeneration === cacheToken.generation
	);
}

async function loadExtensionModule(extensionPath: string, cacheToken?: ExtensionCacheToken) {
	if (isCurrentCacheToken(cacheToken)) {
		const cachedFactory = extensionCache.get(extensionPath);
		if (cachedFactory) {
			return cachedFactory;
		}
	}

	const createJiti = await loadCreateJiti();
	const jiti = createJiti(import.meta.url, {
		moduleCache: false,
		// Bun uses modules embedded in the executable. Source TypeScript reuses the
		// host-resolved modules and root tsconfig paths. Built Node uses dist aliases.
		...(isBunBinary
			? { virtualModules: await loadVirtualModules(), tryNative: false }
			: isTypeScriptSourceRuntime
				? { virtualModules: await loadVirtualModules(), tsconfigPaths: true }
				: { alias: getAliases() }),
	});

	const module = await jiti.import(extensionPath, { default: true });
	const factory = module as ExtensionFactory;
	if (typeof factory !== "function") {
		return undefined;
	}
	if (isCurrentCacheToken(cacheToken)) {
		extensionCache.set(extensionPath, factory);
	}
	return factory;
}

/**
 * Create an Extension object with empty collections.
 */
function createExtension(extensionPath: string, resolvedPath: string): Extension {
	const source =
		extensionPath.startsWith("<") && extensionPath.endsWith(">")
			? extensionPath.slice(1, -1).split(":")[0] || "temporary"
			: "local";
	const baseDir = extensionPath.startsWith("<") ? undefined : path.dirname(resolvedPath);

	return {
		path: extensionPath,
		resolvedPath,
		sourceInfo: createSyntheticSourceInfo(extensionPath, { source, baseDir }),
		handlers: new Map(),
		observers: new Map(),
		tools: new Map(),
		messageRenderers: new Map(),
		toolRenderers: undefined,
		entryRenderers: new Map(),
		commands: new Map(),
		flags: new Map(),
		shortcuts: new Map(),
	};
}

async function initializeExtension(
	factory: ExtensionFactory,
	extensionPath: string,
	resolvedPath: string,
	cwd: string,
	eventBus: EventBus,
	runtime: ExtensionRuntime,
): Promise<Extension> {
	const extension = createExtension(extensionPath, resolvedPath);
	const load = createExtensionAPI(extension, runtime, cwd, eventBus);
	try {
		await factory(load.api);
		load.commit();
	} catch (error) {
		load.discard();
		throw error;
	}
	time(`${extensionPath} factory`, "extensions");
	return extension;
}

async function loadExtension(
	extensionPath: string,
	cwd: string,
	eventBus: EventBus,
	runtime: ExtensionRuntime,
	cacheToken?: ExtensionCacheToken,
): Promise<{ extension: Extension | null; error: string | null }> {
	const resolvedPath = resolvePath(extensionPath, cwd, { normalizeUnicodeSpaces: true });

	try {
		const factory = await loadExtensionModule(resolvedPath, cacheToken);
		time(`${extensionPath} module import`, "extensions");
		if (!factory) {
			return { extension: null, error: `Extension does not export a valid factory function: ${extensionPath}` };
		}

		const extension = await initializeExtension(factory, extensionPath, resolvedPath, cwd, eventBus, runtime);

		return { extension, error: null };
	} catch (err) {
		const message = err instanceof Error ? err.message : String(err);
		return { extension: null, error: `Failed to load extension: ${message}` };
	}
}

/**
 * Create an Extension from an inline factory function.
 */
export async function loadExtensionFromFactory(
	factory: ExtensionFactory,
	cwd: string,
	eventBus: EventBus,
	runtime: ExtensionRuntime,
	extensionPath = "<inline>",
): Promise<Extension> {
	const resolvedCwd = resolvePath(cwd);
	return initializeExtension(factory, extensionPath, extensionPath, resolvedCwd, eventBus, runtime);
}

/**
 * Load extensions from paths.
 */
async function loadExtensionsInternal(
	paths: string[],
	cwd: string,
	eventBus?: EventBus,
	runtime?: ExtensionRuntime,
	useCache = false,
): Promise<LoadExtensionsResult> {
	const extensions: Extension[] = [];
	const errors: Array<{ path: string; error: string }> = [];
	const cacheToken = useCache ? useExtensionCacheCwd(cwd) : undefined;
	const resolvedCwd = cacheToken?.cwd ?? resolvePath(cwd);
	const resolvedEventBus = eventBus ?? createEventBus();
	const resolvedRuntime = runtime ?? createExtensionRuntime();

	for (const extPath of paths) {
		const { extension, error } = await loadExtension(
			extPath,
			resolvedCwd,
			resolvedEventBus,
			resolvedRuntime,
			cacheToken,
		);

		if (error) {
			errors.push({ path: extPath, error });
			continue;
		}

		if (extension) {
			extensions.push(extension);
		}
	}

	return {
		extensions,
		errors,
		runtime: resolvedRuntime,
	};
}

export async function loadExtensions(
	paths: string[],
	cwd: string,
	eventBus?: EventBus,
	runtime?: ExtensionRuntime,
): Promise<LoadExtensionsResult> {
	return loadExtensionsInternal(paths, cwd, eventBus, runtime);
}

export async function loadExtensionsCached(
	paths: string[],
	cwd: string,
	eventBus?: EventBus,
	runtime?: ExtensionRuntime,
): Promise<LoadExtensionsResult> {
	return loadExtensionsInternal(paths, cwd, eventBus, runtime, true);
}

function isExtensionFile(name: string): boolean {
	return name.endsWith(".ts") || name.endsWith(".js");
}

/**
 * Resolve extension entry points from a directory.
 *
 * Checks for:
 * 1. package.json with "pi.extensions" field -> returns declared paths
 * 2. index.ts or index.js -> returns the index file
 *
 * Returns resolved paths or null if no entry points found.
 */
function resolveExtensionEntries(dir: string): string[] | null {
	// Check for package.json with "pi" field first
	const packageJsonPath = path.join(dir, "package.json");
	if (fs.existsSync(packageJsonPath)) {
		const manifest = readPiManifest(packageJsonPath);
		if (manifest?.extensions?.length) {
			const entries: string[] = [];
			for (const extPath of manifest.extensions) {
				const resolvedExtPath = path.resolve(dir, extPath);
				if (fs.existsSync(resolvedExtPath)) {
					entries.push(resolvedExtPath);
				}
			}
			if (entries.length > 0) {
				return entries;
			}
		}
	}

	// Check for index.ts or index.js
	const indexTs = path.join(dir, "index.ts");
	const indexJs = path.join(dir, "index.js");
	if (fs.existsSync(indexTs)) {
		return [indexTs];
	}
	if (fs.existsSync(indexJs)) {
		return [indexJs];
	}

	return null;
}

/**
 * Discover extensions in a directory.
 *
 * Discovery rules:
 * 1. Direct files: `extensions/*.ts` or `*.js` → load
 * 2. Subdirectory with index: `extensions/* /index.ts` or `index.js` → load
 * 3. Subdirectory with package.json: `extensions/* /package.json` with "pi" field → load what it declares
 *
 * No recursion beyond one level. Complex packages must use package.json manifest.
 */
function discoverExtensionsInDir(dir: string): string[] {
	if (!fs.existsSync(dir)) {
		return [];
	}

	const discovered: string[] = [];

	try {
		const entries = fs.readdirSync(dir, { withFileTypes: true }).sort((left, right) =>
			compareCanonicalIdentifiers(left.name, right.name),
		);

		for (const entry of entries) {
			const entryPath = path.join(dir, entry.name);

			// 1. Direct files: *.ts or *.js
			if ((entry.isFile() || entry.isSymbolicLink()) && isExtensionFile(entry.name)) {
				discovered.push(entryPath);
				continue;
			}

			// 2 & 3. Subdirectories
			if (entry.isDirectory() || entry.isSymbolicLink()) {
				const entries = resolveExtensionEntries(entryPath);
				if (entries) {
					discovered.push(...entries);
				}
			}
		}
	} catch {
		return [];
	}

	return discovered;
}

/**
 * Discover and load extensions from standard locations.
 */
export async function discoverAndLoadExtensions(
	configuredPaths: string[],
	cwd: string,
	agentDir: string = getAgentDir(),
	eventBus?: EventBus,
): Promise<LoadExtensionsResult> {
	const resolvedCwd = resolvePath(cwd);
	const resolvedAgentDir = resolvePath(agentDir);
	const allPaths: string[] = [];
	const seen = new Set<string>();

	const addPaths = (paths: string[]) => {
		for (const p of paths) {
			const resolved = path.resolve(p);
			if (!seen.has(resolved)) {
				seen.add(resolved);
				allPaths.push(p);
			}
		}
	};

	// 1. Project-local extensions: cwd/${CONFIG_DIR_NAME}/extensions/
	const localExtDir = path.join(resolvedCwd, CONFIG_DIR_NAME, "extensions");
	addPaths(discoverExtensionsInDir(localExtDir));

	// 2. Global extensions: agentDir/extensions/
	const globalExtDir = path.join(resolvedAgentDir, "extensions");
	addPaths(discoverExtensionsInDir(globalExtDir));

	// 3. Explicitly configured paths
	for (const p of configuredPaths) {
		const resolved = resolvePath(p, resolvedCwd, { normalizeUnicodeSpaces: true });
		if (fs.existsSync(resolved) && fs.statSync(resolved).isDirectory()) {
			// Check for package.json with pi manifest or index.ts
			const entries = resolveExtensionEntries(resolved);
			if (entries) {
				addPaths(entries);
				continue;
			}
			// No explicit entries - discover individual files in directory
			addPaths(discoverExtensionsInDir(resolved));
			continue;
		}

		addPaths([resolved]);
	}

	return loadExtensions(allPaths, resolvedCwd, eventBus);
}
