import { MUTATION_READ_SOURCE, readFileGeneration, verifyMutationReadSource } from "../tools/read-window.ts";
import { NATIVE_FILE_REVISION } from "./file-host.ts";
import { randomBytes } from "node:crypto";
import { lstat, open, realpath } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { TextDecoder } from "node:util";
import { DEFAULT_MAX_BYTES, formatSize, truncateHead } from "../tools/truncate.ts";
import { generateDiffString, generateUnifiedPatch } from "../tools/edit-diff.ts";
import type { ReadToolDetails, ReadToolInput } from "../tools/read.ts";
import { resolveToolPath, sha256 } from "./file-path.ts";
import {
  computeSnapshotLineId,
  formatSnapshotLineExcerpt,
  formatSnapshotReadText,
  findUniqueSnapshotLineSuggestion,
  parseSnapshotLineReference,
  stripCopiedSnapshotPrefixes,
  validateSnapshotLineReference,
} from "./snapshot-line-protocol.ts";
import { assertNoNewSyntaxDiagnostics } from "./snapshot-syntax-guard.ts";
import { snapshotPreview, type PreviewBudget, type ChangePreview } from "./change-preview.ts";
import { capturePathIdentity, type PathIdentity } from "./native-file-core.ts";
import { commitPreparedFile, FileCommitError, type FileCommitReceipt, type CommitMetadata } from "./file-commit.ts";
import { selectCommitMetadata } from "./file-commit-metadata.ts";
import { SNAPSHOT_ID_REGEX as SNAPSHOT_ID_PATTERN } from "./regex.ts";
import {
  captureCompactSnapshot,
  compactFileLimit,
  type CompactCapturedLine,
} from "./compact-snapshot-capture.ts";
export const SNAPSHOT_EDIT_ANNOTATION_PREFIX = "[Snapshot edit]";
export const MAX_SNAPSHOT_LINE_EDITS = 20;
const MAX_SNAPSHOT_FILE_BYTES = 2 * 1024 * 1024;
const MAX_SNAPSHOT_TOTAL_BYTES = 8 * 1024 * 1024;
const MAX_SNAPSHOT_RECEIPTS = 128;
const MAX_SNAPSHOT_EDIT_BYTES = 256 * 1024;
const strictUtf8Decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });

export type SnapshotLineEditKind = "replace" | "delete" | "insert_before" | "insert_after";

export interface SnapshotLineEdit {
  kind: SnapshotLineEditKind;
  start: string;
  end?: string;
  newLines?: string[];
}

interface FileIdentity {
  dev: bigint;
  ino: bigint;
  size: bigint;
  mtimeNs: bigint;
  ctimeNs: bigint;
}

interface SnapshotReceiptBase {
  id: string;
  sessionId: string;
  canonicalPath: string;
  identity: FileIdentity;
  sha256: string;
  firstSeenLine: number;
  lastSeenLine: number;
  residentBytes: number;
}

interface FullSnapshotReceipt extends SnapshotReceiptBase {
  mode: "full";
  bytes: Buffer;
}


export interface CompactSnapshotReceipt extends SnapshotReceiptBase {
  mode: "compact";
  fileBytes: number;
  totalLines: number;
  bomBytes: 0 | 3;
  visibleLines: CompactCapturedLine[];
  beforeBoundary?: CompactCapturedLine;
  afterBoundary?: CompactCapturedLine;
}

type SnapshotReceipt = FullSnapshotReceipt | CompactSnapshotReceipt;

interface PhysicalLine {
  start: number;
  contentEnd: number;
  end: number;
  eol: "\n" | "\r\n" | "";
}

interface PreparedByteEdit {
  index: number;
  start: number;
  end: number;
  replacement: Buffer;
}

export interface SnapshotReadResult {
  content: Array<{ type: string; text?: string; readBoundary?: "lines" }>;
  details?: ReadToolDetails;
}
export interface SnapshotLineEditResult {
  commit: FileCommitReceipt;
  previousSha256: string;
  sha256: string;
  replacements: number;
  deduplicatedEdits: number;
  changedBytes: number;
  diff: string;
  patch: string;
  firstChangedLine?: number;
  reservationId?: number;
}
export interface SnapshotLineEditHooks {
  revisions?: FileRevisions;
  assertPathAllowed: () => Promise<string>;
  reserveMutation?: (changedBytes: number) => number;
  beforeCommit?: () => void | Promise<void>;
  assertCurrent?: () => void;
  afterCommit?: () => void | Promise<void>;
  previewBudget?: PreviewBudget;
  previewOnly?: boolean;
  preparedTarget?: PathIdentity;
  preparedParent?: PathIdentity;
  commitSelected?: (metadata: Pick<CommitMetadata, "strategy" | "reason">) => void;
}
/** One session owns at most 128 receipts / 8 MiB; clear/dispose drops all source references. */
export class FileRevisions {
  readonly schemaVersion = 3;
  private readonly snapshots = new Map<string, SnapshotReceipt>();
  private bytes = 0;
  private epoch = 0;
  private closed = false;

  readonly sessionId?: string;
  constructor(sessionId?: string) { this.sessionId = sessionId; }

  get generation(): number { return this.epoch; }
  get size(): number { return this.snapshots.size; }
  get residentBytes(): number { return this.bytes; }
  get(id: string): SnapshotReceipt | undefined { return this.snapshots.get(id); }

  /** Invocation boundary only: bounded by 128 receipts; the newest read wins. */
  latest(canonicalPath: string): string | undefined {
    let id: string | undefined;
    for (const receipt of this.snapshots.values()) if (receipt.canonicalPath === canonicalPath) id = receipt.id;
    return id;
  }

  invalidatePath(canonicalPath: string): void {
    for (const receipt of this.snapshots.values()) if (receipt.canonicalPath === canonicalPath) this.forget(receipt.id);
  }

  remember(receipt: SnapshotReceipt, generation: number): boolean {
    if (this.closed || generation !== this.epoch || (this.sessionId !== undefined && this.sessionId !== receipt.sessionId)
      || receipt.residentBytes > MAX_SNAPSHOT_TOTAL_BYTES) return false;
    this.forget(receipt.id);
    while (this.snapshots.size > 0 && (this.snapshots.size >= MAX_SNAPSHOT_RECEIPTS
      || this.bytes + receipt.residentBytes > MAX_SNAPSHOT_TOTAL_BYTES)) {
      const oldest = this.snapshots.keys().next().value;
      if (oldest === undefined) break;
      this.forget(oldest);
    }
    this.snapshots.set(receipt.id, receipt);
    this.bytes += receipt.residentBytes;
    return true;
  }

  forget(id: string): void {
    const receipt = this.snapshots.get(id);
    if (!receipt) return;
    this.snapshots.delete(id);
    this.bytes -= receipt.residentBytes;
  }

  assertCurrent(receipt: SnapshotReceipt): void {
    if (this.closed || this.snapshots.get(receipt.id) !== receipt) {
      throw new Error("[SNAPSHOT_EDIT_STALE] Snapshot was cleared, expired or consumed. No change.");
    }
  }

  clear(): void { this.epoch++; this.snapshots.clear(); this.bytes = 0; }
  dispose(): void { this.closed = true; this.clear(); }
}

// Legacy extension callers share only this compatibility store. Native sessions pass their own owner.
const SNAPSHOT_STORE = Symbol.for("pi.mutation-guard.snapshot-line-store.v1");
type SnapshotGlobal = typeof globalThis & { [SNAPSHOT_STORE]?: FileRevisions };

function snapshotStore(): FileRevisions {
  const root = globalThis as SnapshotGlobal;
  const current = root[SNAPSHOT_STORE];
  if (current?.schemaVersion === 3) return current;
  const created = new FileRevisions();
  root[SNAPSHOT_STORE] = created;
  return created;
}

export function resetSnapshotLineStore(): void {
  snapshotStore().clear();
}

function identityFromStat(info: Awaited<ReturnType<Awaited<ReturnType<typeof open>>["stat"]>>): FileIdentity {
  const bigint = info as unknown as {
    dev: bigint;
    ino: bigint;
    size: bigint;
    mtimeNs: bigint;
    ctimeNs: bigint;
  };
  return {
    dev: bigint.dev,
    ino: bigint.ino,
    size: bigint.size,
    mtimeNs: bigint.mtimeNs,
    ctimeNs: bigint.ctimeNs,
  };
}

function sameIdentity(left: FileIdentity, right: FileIdentity): boolean {
  return left.dev === right.dev && left.ino === right.ino;
}

function sameCaptureState(left: FileIdentity, right: FileIdentity): boolean {
  return sameIdentity(left, right)
    && left.size === right.size
    && left.mtimeNs === right.mtimeNs
    && left.ctimeNs === right.ctimeNs;
}

async function captureStableFile(path: string, limit = MAX_SNAPSHOT_FILE_BYTES): Promise<{ canonicalPath: string; identity: FileIdentity; bytes: Buffer }> {
  const canonicalPath = await realpath(resolve(path));
  const handle = await open(canonicalPath, "r");
  try {
    const beforeInfo = await handle.stat({ bigint: true });
    if (!beforeInfo.isFile()) throw new Error("Snapshot edit supports regular files only.");
    if (beforeInfo.size > BigInt(limit)) {
      throw new Error(`Snapshot edit supports files up to ${formatSize(limit)}.`);
    }
    const before = identityFromStat(beforeInfo);
    // Fixed extent plus one sentinel byte: external growth cannot turn capture into an unbounded read.
    const buffer = Buffer.allocUnsafe(Number(before.size) + 1);
    let offset = 0;
    while (offset < buffer.length) {
      const next = await handle.read(buffer, offset, Math.min(64 * 1024, buffer.length - offset), offset);
      if (!next.bytesRead) break;
      offset += next.bytesRead;
    }
    const bytes = buffer.subarray(0, offset);
    const afterInfo = await handle.stat({ bigint: true });
    const after = identityFromStat(afterInfo);
    if (!sameCaptureState(before, after) || BigInt(bytes.byteLength) !== after.size) {
      throw new Error("File changed while the snapshot was being captured.");
    }
    return { canonicalPath, identity: after, bytes };
  } finally {
    await handle.close();
  }
}

function primaryText(result: SnapshotReadResult): string | undefined {
  if (result.content.length !== 1) return undefined;
  const item = result.content[0];
  return item?.type === "text" && typeof item.text === "string" ? item.text : undefined;
}

interface NativeReadProjection {
  text: string;
  firstLine: number;
  lastLine: number;
  outputLines: number;
}

function nativeReadProjection(bytes: Buffer, input: ReadToolInput): NativeReadProjection | undefined {
  let decoded: string;
  try {
    decoded = strictUtf8Decoder.decode(bytes);
  } catch {
    return undefined;
  }
  if (decoded.includes("\0")) return undefined;
  const allLines = decoded.split("\n");
  const startIndex = input.offset ? Math.max(0, input.offset - 1) : 0;
  if (startIndex >= allLines.length) return undefined;
  const firstLine = startIndex + 1;
  let selectedContent: string;
  let userLimitedLines: number | undefined;
  if (input.limit !== undefined) {
    const endIndex = Math.min(startIndex + input.limit, allLines.length);
    selectedContent = allLines.slice(startIndex, endIndex).join("\n");
    userLimitedLines = endIndex - startIndex;
  } else {
    selectedContent = allLines.slice(startIndex).join("\n");
  }
  const truncation = truncateHead(selectedContent);
  if (truncation.firstLineExceedsLimit) return undefined;
  let text: string;
  let outputLines: number;
  if (truncation.truncated) {
    outputLines = truncation.outputLines;
    const endLine = firstLine + outputLines - 1;
    const nextOffset = endLine + 1;
    text = truncation.content;
    if (truncation.truncatedBy === "lines") {
      text += `\n\n[Showing lines ${firstLine}-${endLine} of ${allLines.length}. Use offset=${nextOffset} to continue.]`;
    } else {
      text += `\n\n[Showing lines ${firstLine}-${endLine} of ${allLines.length} (${formatSize(DEFAULT_MAX_BYTES)} limit). Use offset=${nextOffset} to continue.]`;
    }
  } else if (userLimitedLines !== undefined && startIndex + userLimitedLines < allLines.length) {
    outputLines = userLimitedLines;
    const remaining = allLines.length - (startIndex + userLimitedLines);
    const nextOffset = startIndex + userLimitedLines + 1;
    text = `${truncation.content}\n\n[${remaining} more lines in file. Use offset=${nextOffset} to continue.]`;
  } else {
    outputLines = Math.max(1, allLines.length - startIndex);
    text = truncation.content;
  }
  return { text, firstLine, lastLine: firstLine + outputLines - 1, outputLines };
}

function preciseWindow(result: SnapshotReadResult): ReadToolDetails["window"] {
  const window = result.details?.window, source = (result.content as any)[MUTATION_READ_SOURCE];
  if (!window || !source || window.partial || window.startsPartial || window.binary
    || !Number.isSafeInteger(window.startLine) || window.startLine < 1
    || !Number.isSafeInteger(window.nextLine) || window.nextLine < window.startLine
    || window.startByte !== source.startByte || window.endByte !== source.endByte
    || window.startByte < 0 || window.endByte <= window.startByte) return undefined;
  return window;
}

async function matchesReadSource(canonicalPath: string, result: SnapshotReadResult, bytes?: Buffer): Promise<boolean> {
  const source = (result.content as any)[MUTATION_READ_SOURCE];
  if (!source) return true;
  if (canonicalPath !== source.canonicalPath) return false;
  try {
    if (bytes) return source.startByte >= 0 && source.endByte <= bytes.length
      && sha256(bytes.subarray(source.startByte, source.endByte)) === source.sha256
      && readFileGeneration(await lstat(source.canonicalPath, { bigint: true })) === source.fileGeneration;
    return await verifyMutationReadSource(source);
  }
  catch { return false; } // Optional annotation must not fail a completed read.
}

export async function issueSnapshotForRead(
  sessionId: string,
  cwd: string,
  input: ReadToolInput,
  result: SnapshotReadResult,
  revisions: FileRevisions = snapshotStore(),
): Promise<string | undefined> {
  const generation = revisions.generation;
  const displayed = primaryText(result);
  if (displayed === undefined) return undefined;
  const window = preciseWindow(result);
  if (result.details?.window && !window) return undefined;
  const target = resolveToolPath(cwd, input.path);
  let fullCapture: Awaited<ReturnType<typeof captureStableFile>> | undefined;
  try {
    // Native windows retain only selected lines/boundaries, even for sub-2-MiB files.
    if (!window) fullCapture = await captureStableFile(target);
  } catch {
    // Files above the full-receipt ceiling may still qualify for a compact receipt.
  }
  if (fullCapture) {
    if (!await matchesReadSource(fullCapture.canonicalPath, result, fullCapture.bytes)) return undefined;
    const lines = parsePhysicalLines(fullCapture.bytes);
    if (!lines) return undefined;
    const projection = nativeReadProjection(fullCapture.bytes, input);
    if (!projection || projection.text !== displayed) return undefined;
    const firstSeenLine = Math.max(1, projection.firstLine);
    const lastSeenLine = Math.min(lines.length, projection.lastLine);
    if (lastSeenLine < firstSeenLine && lines.length > 0) return undefined;
    const id = `snap_${randomBytes(16).toString("base64url")}`;
    if (!revisions.remember({
      mode: "full",
      id,
      sessionId,
      canonicalPath: fullCapture.canonicalPath,
      identity: fullCapture.identity,
      bytes: fullCapture.bytes,
      sha256: sha256(fullCapture.bytes),
      firstSeenLine,
      lastSeenLine,
      residentBytes: fullCapture.bytes.byteLength,
    }, generation)) return undefined;
    Object.defineProperty(result, NATIVE_FILE_REVISION, { value: id });
    result.content[0] = {
      type: "text",
      readBoundary: "lines",
      text: formatSnapshotReadText(displayed, firstSeenLine, lastSeenLine - firstSeenLine + 1),
    };
    return lines.length === 0
      ? `${SNAPSHOT_EDIT_ANNOTATION_PREFIX} snapshot=${id}; empty file. Use write to replace this revision.`
      : `${SNAPSHOT_EDIT_ANNOTATION_PREFIX} snapshot=${id}; editable lines=${firstSeenLine}-${lastSeenLine}. Use this snapshot and its LINE#ID anchors together.`;
  }
  let compact: Awaited<ReturnType<typeof captureCompactSnapshot>>;
  try {
    compact = await captureCompactSnapshot(target, input, displayed, { window });
  } catch {
    return undefined;
  }
  if (!compact) return undefined;
  if (!await matchesReadSource(compact.canonicalPath, result)) return undefined;
  const id = `snap_${randomBytes(16).toString("base64url")}`;
  if (!revisions.remember({
    mode: "compact",
    id,
    sessionId,
    canonicalPath: compact.canonicalPath,
    identity: compact.identity,
    sha256: compact.sha256,
    firstSeenLine: compact.firstSeenLine,
    lastSeenLine: compact.lastSeenLine,
    residentBytes: compact.residentBytes,
    fileBytes: compact.fileBytes,
    totalLines: compact.totalLines,
    bomBytes: compact.bomBytes,
    visibleLines: compact.visibleLines,
    beforeBoundary: compact.beforeBoundary,
    afterBoundary: compact.afterBoundary,
  }, generation)) return undefined;
  Object.defineProperty(result, NATIVE_FILE_REVISION, { value: id });
  result.content[0] = {
    type: "text",
    readBoundary: "lines",
    text: formatSnapshotReadText(displayed, compact.firstSeenLine, compact.visibleLines.length),
  };
  return `${SNAPSHOT_EDIT_ANNOTATION_PREFIX} snapshot=${id}; editable lines=${compact.firstSeenLine}-${compact.lastSeenLine}. Use this snapshot and its LINE#ID anchors together.`;
}
function parsePhysicalLines(bytes: Buffer): PhysicalLine[] | undefined {
  let offset = 0;
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) offset = 3;
  try {
    strictUtf8Decoder.decode(bytes.subarray(offset));
  } catch {
    return undefined;
  }
  const lines: PhysicalLine[] = [];
  let lineStart = offset;
  for (let index = offset; index < bytes.length; index++) {
    if (bytes[index] === 0x0d && bytes[index + 1] !== 0x0a) return undefined;
    if (bytes[index] !== 0x0a) continue;
    const crlf = index > lineStart && bytes[index - 1] === 0x0d;
    lines.push({
      start: lineStart,
      contentEnd: crlf ? index - 1 : index,
      end: index + 1,
      eol: crlf ? "\r\n" : "\n",
    });
    lineStart = index + 1;
  }
  if (lineStart < bytes.length) {
    lines.push({ start: lineStart, contentEnd: bytes.length, end: bytes.length, eol: "" });
  }
  return lines;
}

function preferredEol(lines: readonly PhysicalLine[], lineIndex: number): "\n" | "\r\n" {
  const direct = lines[lineIndex]?.eol;
  if (direct) return direct;
  for (let index = lineIndex - 1; index >= 0; index--) if (lines[index].eol) return lines[index].eol as "\n" | "\r\n";
  for (let index = lineIndex + 1; index < lines.length; index++) if (lines[index].eol) return lines[index].eol as "\n" | "\r\n";
  return "\n";
}

function physicalLineText(bytes: Buffer, line: PhysicalLine): string {
  return strictUtf8Decoder.decode(bytes.subarray(line.start, line.contentEnd));
}

function normalizedNewLines(edit: SnapshotLineEdit, index: number): string[] {
  if (edit.kind === "delete") {
    if (edit.newLines !== undefined) throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].newLines is not allowed for delete.`);
    return [];
  }
  if (!Array.isArray(edit.newLines) || edit.newLines.length === 0) {
    throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].newLines must be a non-empty string array.`);
  }
  const stripped = stripCopiedSnapshotPrefixes(edit.newLines);
  for (let lineIndex = 0; lineIndex < stripped.length; lineIndex++) {
    const line = stripped[lineIndex];
    if (typeof line !== "string") throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].newLines[${lineIndex}] must be a string.`);
    if (line.includes("\n") || line.includes("\r")) {
      throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].newLines[${lineIndex}] must contain exactly one physical line.`);
    }
    if (line.includes("\0")) throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].newLines[${lineIndex}] contains NUL.`);
  }
  return stripped;
}

export function validateInsertionFields(edit: SnapshotLineEdit, index: number): void {
  if (edit.end === undefined) return;
  // Independent field checks only: no payload assembly or parser work on invalid input.
  let related = "";
  try { normalizedNewLines(edit, index); }
  catch (error) { related = `\n${error instanceof Error ? error.message : String(error)}`; }
  throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}] insertion requires one surviving start; omit end. newLines: only intended inserted lines, no copied locating context.${related}\nNo change. Correct these fields using this snapshot if still current; otherwise read again.`);
}

function payloadBuffer(lines: readonly string[], eol: "\n" | "\r\n", index: number, maxBytes: number): Buffer {
  const text = lines.join(eol);
  const bytes = Buffer.byteLength(text, "utf8");
  if (bytes > maxBytes) {
    throw new Error(`[SNAPSHOT_EDIT_BUDGET] edits[${index}].newLines exceeds the remaining bounded edit scope.`);
  }
  return Buffer.from(text, "utf8");
}

function editKey(edit: SnapshotLineEdit): string {
  return JSON.stringify([edit.kind, edit.start.trim(), edit.end?.trim() ?? "", edit.newLines ?? null]);
}

function deduplicateEdits(edits: readonly SnapshotLineEdit[]): { edits: SnapshotLineEdit[]; deduplicatedEdits: number } {
  const seen = new Set<string>();
  const unique: SnapshotLineEdit[] = [];
  for (const edit of edits) {
    const key = editKey(edit);
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(edit);
  }
  return { edits: unique, deduplicatedEdits: edits.length - unique.length };
}

function assertNoBoundaryEcho(
  index: number,
  startLine: number,
  endLine: number,
  newLines: readonly string[],
  snapshotLines: readonly string[],
): void {
  if (newLines.length === 0) return;
  const before = snapshotLines[startLine - 2];
  const after = snapshotLines[endLine];
  if (before !== undefined && newLines[0] === before) {
    throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats surviving line ${startLine - 1}; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
  }
  if (after !== undefined && newLines[newLines.length - 1] === after) {
    throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats surviving line ${endLine + 1}; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
  }
}

interface PreparedEdits {
  output: Buffer;
  byteEdits: PreparedByteEdit[];
  changedBytes: number;
  replacements: number;
  deduplicatedEdits: number;
}

function prepareEdits(receipt: FullSnapshotReceipt, requestedEdits: readonly SnapshotLineEdit[]): PreparedEdits {
  if (requestedEdits.length === 0 || requestedEdits.length > MAX_SNAPSHOT_LINE_EDITS) {
    throw new Error(`[SNAPSHOT_EDIT_INVALID] Provide 1-${MAX_SNAPSHOT_LINE_EDITS} line operations.`);
  }
  const deduplicated = deduplicateEdits(requestedEdits);
  const edits = deduplicated.edits;
  const lines = parsePhysicalLines(receipt.bytes);
  if (!lines || lines.length === 0) throw new Error("[SNAPSHOT_EDIT_UNSUPPORTED] The snapshot is not supported line-oriented UTF-8 text.");
  const snapshotLines = lines.map((line) => physicalLineText(receipt.bytes, line));
  const prepared: PreparedByteEdit[] = [];
  let changedBytes = 0;
  for (let index = 0; index < edits.length; index++) {
    const edit = edits[index];
    const startLine = validateSnapshotLineReference(edit.start, `edits[${index}].start`, snapshotLines, receipt.firstSeenLine, receipt.lastSeenLine);
    const insertion = edit.kind === "insert_before" || edit.kind === "insert_after";
    if (insertion) validateInsertionFields(edit, index);
    const endLine = edit.end === undefined
      ? startLine
      : validateSnapshotLineReference(edit.end, `edits[${index}].end`, snapshotLines, receipt.firstSeenLine, receipt.lastSeenLine);
    if (endLine < startLine) throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].end precedes start.`);
    const startIndex = startLine - 1;
    const eol = preferredEol(lines, startIndex);
    const newLines = normalizedNewLines(edit, index);
    let start: number;
    let end: number;
    let replacement: Buffer;
    if (edit.kind === "replace" || edit.kind === "delete") {
      const finalLine = lines[endLine - 1];
      start = lines[startIndex].start;
      end = finalLine.end;
      assertNoBoundaryEcho(index, startLine, endLine, newLines, snapshotLines);
      if (edit.kind === "delete") {
        replacement = Buffer.alloc(0);
      } else {
        const removedBytes = end - start;
        const terminatorBytes = finalLine.eol ? Buffer.byteLength(finalLine.eol) : 0;
        const payload = payloadBuffer(newLines, eol, index, Math.max(0, MAX_SNAPSHOT_EDIT_BYTES - changedBytes - removedBytes - terminatorBytes));
        replacement = finalLine.eol ? Buffer.concat([payload, Buffer.from(finalLine.eol)]) : payload;
      }
    } else if (edit.kind === "insert_before" || edit.kind === "insert_after") {
      const line = lines[startIndex];
      const payload = payloadBuffer(newLines, eol, index, Math.max(0, MAX_SNAPSHOT_EDIT_BYTES - changedBytes - Buffer.byteLength(eol)));
      if (edit.kind === "insert_before") {
        if (newLines[newLines.length - 1] === snapshotLines[startIndex]) {
          throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats its surviving anchor; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
        }
        start = line.start;
        end = line.start;
        replacement = Buffer.concat([payload, Buffer.from(eol)]);
      } else if (line.eol) {
        if (newLines[0] === snapshotLines[startIndex]) {
          throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats its surviving anchor; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
        }
        start = line.end;
        end = line.end;
        replacement = Buffer.concat([payload, Buffer.from(eol)]);
      } else {
        start = line.end;
        end = line.end;
        replacement = Buffer.concat([Buffer.from(eol), payload]);
      }
    } else {
      throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].kind is unsupported.`);
    }
    changedBytes += end - start + replacement.byteLength;
    prepared.push({ index: requestedEdits.indexOf(edit), start, end, replacement });
  }
  if (changedBytes > MAX_SNAPSHOT_EDIT_BYTES) {
    throw new Error(`[SNAPSHOT_EDIT_BUDGET] Requested ${changedBytes} scoped bytes; allowed ${MAX_SNAPSHOT_EDIT_BYTES}.`);
  }
  prepared.sort((left, right) => left.start - right.start || left.end - right.end || left.index - right.index);
  for (let index = 1; index < prepared.length; index++) {
    const previous = prepared[index - 1];
    const current = prepared[index];
    if (current.start < previous.end || (current.start === previous.start && current.end === previous.end)) {
      throw new Error(`[SNAPSHOT_EDIT_OVERLAP] edits[${previous.index}] and edits[${current.index}] overlap or share one insertion point.`);
    }
    if (previous.start === previous.end && current.start <= previous.start && previous.start <= current.end) {
      throw new Error(`[SNAPSHOT_EDIT_OVERLAP] insertion edits[${previous.index}] touches edits[${current.index}].`);
    }
    if (current.start === current.end && previous.start <= current.start && current.start <= previous.end) {
      throw new Error(`[SNAPSHOT_EDIT_OVERLAP] insertion edits[${current.index}] touches edits[${previous.index}].`);
    }
  }
  const chunks: Buffer[] = [];
  let cursor = 0;
  for (const edit of prepared) {
    chunks.push(receipt.bytes.subarray(cursor, edit.start), edit.replacement);
    cursor = edit.end;
  }
  chunks.push(receipt.bytes.subarray(cursor));
  const output = Buffer.concat(chunks);
  if (output.byteLength > MAX_SNAPSHOT_FILE_BYTES) {
    throw new Error(`[SNAPSHOT_EDIT_BUDGET] Result exceeds ${formatSize(MAX_SNAPSHOT_FILE_BYTES)}.`);
  }
  if (output.equals(receipt.bytes)) throw new Error("[SNAPSHOT_EDIT_NO_OP] The requested operations do not change the file.");
  return { output, byteEdits: prepared, changedBytes, replacements: edits.length, deduplicatedEdits: deduplicated.deduplicatedEdits };
}

function compactLine(receipt: CompactSnapshotReceipt, line: number): CompactCapturedLine | undefined {
  const candidate = receipt.visibleLines[line - receipt.firstSeenLine];
  return candidate?.line === line ? candidate : undefined;
}

function compactMismatchContext(receipt: CompactSnapshotReceipt, line: number): string {
  const low = Math.max(receipt.firstSeenLine, line - 2);
  const high = Math.min(receipt.lastSeenLine, line + 2);
  const output: string[] = [];
  for (let current = low; current <= high; current++) {
    const stored = compactLine(receipt, current);
    if (!stored) continue;
    output.push(`${current === line ? ">>> " : "    "}${formatSnapshotLineExcerpt(current, stored.text)}`);
  }
  return output.join("\n");
}

function validateCompactLineReference(
  value: string,
  field: string,
  receipt: CompactSnapshotReceipt,
): CompactCapturedLine {
  const reference = parseSnapshotLineReference(value, field);
  if (reference.line < 1 || reference.line > receipt.totalLines) {
    throw new Error(`[SNAPSHOT_EDIT_INVALID] ${field} line ${reference.line} is outside the file.`);
  }
  if (reference.line < receipt.firstSeenLine || reference.line > receipt.lastSeenLine) {
    throw new Error(`[SNAPSHOT_EDIT_UNSEEN] ${field} line ${reference.line} is outside observed lines ${receipt.firstSeenLine}-${receipt.lastSeenLine}. No change.\nRead the needed range; use that read's snapshot and LINE#ID anchors.`);
  }
  const line = compactLine(receipt, reference.line);
  if (!line) throw new Error(`[SNAPSHOT_EDIT_UNSEEN] ${field} line ${reference.line} is not retained by this compact snapshot. No change.\nRead the needed range; use that read's snapshot and LINE#ID anchors.`);
  if (computeSnapshotLineId(reference.line, line.text) !== reference.id) {
    const context = compactMismatchContext(receipt, reference.line);
    const suggestion = findUniqueSnapshotLineSuggestion(
      reference.id,
      receipt.firstSeenLine,
      receipt.lastSeenLine,
      (candidate) => compactLine(receipt, candidate)?.text,
    );
    throw new Error(
      `[SNAPSHOT_EDIT_MISMATCH] ${field} ${reference.line}#${reference.id} does not match the immutable snapshot. No change.\nCorrect the anchor from this snapshot's observed lines below if still current; otherwise read again.${suggestion ? ` Did you mean ${suggestion}?` : ""}${context ? `\n${context}` : ""}`,
    );
  }
  return line;
}

function compactPreferredEol(receipt: CompactSnapshotReceipt, line: number): "\n" | "\r\n" {
  const direct = compactLine(receipt, line)?.eol;
  if (direct) return direct;
  for (let current = line - 1; current >= receipt.firstSeenLine; current--) {
    const eol = compactLine(receipt, current)?.eol;
    if (eol) return eol;
  }
  if (receipt.beforeBoundary?.eol) return receipt.beforeBoundary.eol;
  for (let current = line + 1; current <= receipt.lastSeenLine; current++) {
    const eol = compactLine(receipt, current)?.eol;
    if (eol) return eol;
  }
  if (receipt.afterBoundary?.eol) return receipt.afterBoundary.eol;
  return "\n";
}

function compactBoundaryText(receipt: CompactSnapshotReceipt, line: number): string | undefined {
  if (line < 1 || line > receipt.totalLines) return undefined;
  return compactLine(receipt, line)?.text
    ?? (receipt.beforeBoundary?.line === line ? receipt.beforeBoundary.text : undefined)
    ?? (receipt.afterBoundary?.line === line ? receipt.afterBoundary.text : undefined);
}

function assertNoCompactBoundaryEcho(
  receipt: CompactSnapshotReceipt,
  index: number,
  startLine: number,
  endLine: number,
  newLines: readonly string[],
): void {
  if (newLines.length === 0) return;
  const before = compactBoundaryText(receipt, startLine - 1);
  const after = compactBoundaryText(receipt, endLine + 1);
  if (before !== undefined && newLines[0] === before) {
    throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats surviving line ${startLine - 1}; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
  }
  if (after !== undefined && newLines[newLines.length - 1] === after) {
    throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats surviving line ${endLine + 1}; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
  }
}

function prepareCompactEdits(
  receipt: CompactSnapshotReceipt,
  current: Buffer,
  requestedEdits: readonly SnapshotLineEdit[],
): PreparedEdits {
  if (requestedEdits.length === 0 || requestedEdits.length > MAX_SNAPSHOT_LINE_EDITS) {
    throw new Error(`[SNAPSHOT_EDIT_INVALID] Provide 1-${MAX_SNAPSHOT_LINE_EDITS} line operations.`);
  }
  const deduplicated = deduplicateEdits(requestedEdits);
  const edits = deduplicated.edits;
  const prepared: PreparedByteEdit[] = [];
  let changedBytes = 0;
  for (let index = 0; index < edits.length; index++) {
    const edit = edits[index];
    const startLine = validateCompactLineReference(edit.start, `edits[${index}].start`, receipt);
    const insertion = edit.kind === "insert_before" || edit.kind === "insert_after";
    if (insertion) validateInsertionFields(edit, index);
    const endLine = edit.end === undefined
      ? startLine
      : validateCompactLineReference(edit.end, `edits[${index}].end`, receipt);
    if (endLine.line < startLine.line) throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].end precedes start.`);
    const eol = compactPreferredEol(receipt, startLine.line);
    const newLines = normalizedNewLines(edit, index);
    let start: number;
    let end: number;
    let replacement: Buffer;
    if (edit.kind === "replace" || edit.kind === "delete") {
      start = startLine.start;
      end = endLine.end;
      assertNoCompactBoundaryEcho(receipt, index, startLine.line, endLine.line, newLines);
      if (edit.kind === "delete") {
        replacement = Buffer.alloc(0);
      } else {
        const removedBytes = end - start;
        const terminatorBytes = endLine.eol ? Buffer.byteLength(endLine.eol) : 0;
        const payload = payloadBuffer(newLines, eol, index, Math.max(0, MAX_SNAPSHOT_EDIT_BYTES - changedBytes - removedBytes - terminatorBytes));
        replacement = endLine.eol ? Buffer.concat([payload, Buffer.from(endLine.eol)]) : payload;
      }
    } else if (edit.kind === "insert_before" || edit.kind === "insert_after") {
      const payload = payloadBuffer(newLines, eol, index, Math.max(0, MAX_SNAPSHOT_EDIT_BYTES - changedBytes - Buffer.byteLength(eol)));
      if (edit.kind === "insert_before") {
        if (newLines[newLines.length - 1] === startLine.text) {
          throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats its surviving anchor; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
        }
        start = startLine.start;
        end = startLine.start;
        replacement = Buffer.concat([payload, Buffer.from(eol)]);
      } else if (startLine.eol) {
        if (newLines[0] === startLine.text) {
          throw new Error(`[SNAPSHOT_EDIT_BOUNDARY] edits[${index}].newLines repeats its surviving anchor; equal text may be intentional. No change.\nOmit accidental locating context, or explicitly replace a covered range including the surviving line for intended repetition; this snapshot remains usable if current.`);
        }
        start = startLine.end;
        end = startLine.end;
        replacement = Buffer.concat([payload, Buffer.from(eol)]);
      } else {
        start = startLine.end;
        end = startLine.end;
        replacement = Buffer.concat([Buffer.from(eol), payload]);
      }
    } else {
      throw new Error(`[SNAPSHOT_EDIT_INVALID] edits[${index}].kind is unsupported.`);
    }
    changedBytes += end - start + replacement.byteLength;
    prepared.push({ index: requestedEdits.indexOf(edit), start, end, replacement });
  }
  if (changedBytes > MAX_SNAPSHOT_EDIT_BYTES) {
    throw new Error(`[SNAPSHOT_EDIT_BUDGET] Requested ${changedBytes} scoped bytes; allowed ${MAX_SNAPSHOT_EDIT_BYTES}.`);
  }
  prepared.sort((left, right) => left.start - right.start || left.end - right.end || left.index - right.index);
  for (let index = 1; index < prepared.length; index++) {
    const previous = prepared[index - 1];
    const next = prepared[index];
    if (next.start < previous.end || (next.start === previous.start && next.end === previous.end)) {
      throw new Error(`[SNAPSHOT_EDIT_OVERLAP] edits[${previous.index}] and edits[${next.index}] overlap or share one insertion point.`);
    }
    if (previous.start === previous.end && next.start <= previous.start && previous.start <= next.end) {
      throw new Error(`[SNAPSHOT_EDIT_OVERLAP] insertion edits[${previous.index}] touches edits[${next.index}].`);
    }
    if (next.start === next.end && previous.start <= next.start && next.start <= previous.end) {
      throw new Error(`[SNAPSHOT_EDIT_OVERLAP] insertion edits[${next.index}] touches edits[${previous.index}].`);
    }
  }
  const chunks: Buffer[] = [];
  let cursor = 0;
  for (const edit of prepared) {
    chunks.push(current.subarray(cursor, edit.start), edit.replacement);
    cursor = edit.end;
  }
  chunks.push(current.subarray(cursor));
  const output = Buffer.concat(chunks);
  const maximum = compactFileLimit(receipt.canonicalPath);
  if (output.byteLength > maximum) throw new Error(`[SNAPSHOT_EDIT_BUDGET] Result exceeds ${formatSize(maximum)}.`);
  if (output.equals(current)) throw new Error("[SNAPSHOT_EDIT_NO_OP] The requested operations do not change the file.");
  return { output, byteEdits: prepared, changedBytes, replacements: edits.length, deduplicatedEdits: deduplicated.deduplicatedEdits };
}
export async function readSnapshotSource(receipt: SnapshotReceipt, revisions: FileRevisions): Promise<Buffer> {
  try {
    const current = await captureStableFile(receipt.canonicalPath, Number(receipt.identity.size));
    if (current.canonicalPath !== receipt.canonicalPath || !sameCaptureState(current.identity, receipt.identity)
      || sha256(current.bytes) !== receipt.sha256) throw new Error("Target identity or content changed.");
    revisions.assertCurrent(receipt);
    return current.bytes;
  } catch (error) {
    revisions.forget(receipt.id);
    throw new Error("[SNAPSHOT_EDIT_STALE] Source changed or is unavailable. No change.\nRead the needed range again; use that read's snapshot and LINE#ID anchors.", { cause: error });
  }
}

export async function resolveSnapshotCanonicalTarget(
  sessionId: string,
  cwd: string,
  path: string,
  snapshotId: string,
  revisions: FileRevisions = snapshotStore(),
): Promise<string> {
  if (!SNAPSHOT_ID_PATTERN.test(snapshotId)) throw new Error("[SNAPSHOT_EDIT_UNKNOWN] Invalid snapshot identifier. No change.\nRead the needed range again; use that read's snapshot and LINE#ID anchors.");
  const receipt = revisions.get(snapshotId);
  if (!receipt || receipt.sessionId !== sessionId) {
    throw new Error("[SNAPSHOT_EDIT_UNKNOWN] Snapshot is absent, expired, consumed, or belongs to another Session. No change.\nRead the needed range again; use that read's snapshot and LINE#ID anchors.");
  }
  const requestedCanonical = await realpath(resolveToolPath(cwd, path));
  revisions.assertCurrent(receipt);
  if (requestedCanonical !== receipt.canonicalPath) {
    throw new Error("[SNAPSHOT_EDIT_PATH] Snapshot does not belong to this exact canonical target.");
  }
  return receipt.canonicalPath;
}
export interface PreparedSnapshotMutation {
  revisions: FileRevisions;
  target: PathIdentity;
  parent: PathIdentity;
  snapshotId: string;
  sessionId: string;
  receipt: SnapshotReceipt;
  byteEdits: PreparedByteEdit[];
  changedBytes: number;
  replacements: number;
  deduplicatedEdits: number;
  diff: string;
  patch: string;
  firstChangedLine?: number;
  preview?: ChangePreview;
}
export async function prepareSnapshotLineMutation(
  sessionId: string,
  cwd: string,
  path: string,
  snapshotId: string,
  edits: readonly SnapshotLineEdit[],
  signal: AbortSignal | undefined,
  hooks: SnapshotLineEditHooks,
): Promise<PreparedSnapshotMutation> {
  if (!SNAPSHOT_ID_PATTERN.test(snapshotId)) throw new Error("[SNAPSHOT_EDIT_UNKNOWN] Invalid snapshot identifier. No change.\nRead the needed range again; use that read's snapshot and LINE#ID anchors.");
  const revisions = hooks.revisions ?? snapshotStore();
  const receipt = revisions.get(snapshotId);
  if (!receipt || receipt.sessionId !== sessionId) throw new Error("[SNAPSHOT_EDIT_UNKNOWN] Snapshot is absent, expired, consumed, or belongs to another Session. No change.\nRead the needed range again; use that read's snapshot and LINE#ID anchors.");
  if (signal?.aborted) throw new Error("Operation aborted");
  const approvedCanonical = await hooks.assertPathAllowed();
  const requestedCanonical = await resolveSnapshotCanonicalTarget(sessionId, cwd, path, snapshotId, revisions);
  if (requestedCanonical !== receipt.canonicalPath || approvedCanonical !== receipt.canonicalPath) {
    throw new Error("[SNAPSHOT_EDIT_PATH] Snapshot does not belong to this exact canonical target.");
  }
  const current = await readSnapshotSource(receipt, revisions);
  const target = hooks.preparedTarget ?? await capturePathIdentity(receipt.canonicalPath);
  const parent = hooks.preparedParent ?? await capturePathIdentity(dirname(receipt.canonicalPath));
  if (target.device !== String(receipt.identity.dev) || target.inode !== String(receipt.identity.ino)
    || target.size !== String(receipt.identity.size) || target.mtime !== String(receipt.identity.mtimeNs)
    || target.ctime !== String(receipt.identity.ctimeNs)) throw new Error("[SNAPSHOT_EDIT_STALE] Prepared identity changed.");
  const prepared = receipt.mode === "full"
    ? prepareEdits(receipt, edits)
    : prepareCompactEdits(receipt, current, edits);
  const beforeText = strictUtf8Decoder.decode(current);
  const afterText = strictUtf8Decoder.decode(prepared.output);
  const preview = hooks.previewBudget ? snapshotPreview(current, prepared.byteEdits, hooks.previewBudget) : undefined;
  const diffResult = hooks.previewOnly ? { diff: "", firstChangedLine: undefined } : generateDiffString(beforeText, afterText);
  await assertNoNewSyntaxDiagnostics(receipt.canonicalPath, beforeText, afterText, edits, prepared.byteEdits);
  const patch = hooks.previewOnly ? "" : generateUnifiedPatch(receipt.canonicalPath, beforeText, afterText);
  revisions.assertCurrent(receipt);
  return { revisions, target, parent, snapshotId, sessionId, receipt, byteEdits: prepared.byteEdits, changedBytes: prepared.changedBytes,
    replacements: prepared.replacements, deduplicatedEdits: prepared.deduplicatedEdits,
    diff: diffResult.diff, patch, firstChangedLine: diffResult.firstChangedLine, preview };
}

export async function executeSnapshotLineEdit(
  sessionId: string, cwd: string, path: string, snapshotId: string, edits: readonly SnapshotLineEdit[],
  signal: AbortSignal | undefined, hooks: SnapshotLineEditHooks,
): Promise<SnapshotLineEditResult> {
  const plan = await prepareSnapshotLineMutation(sessionId, cwd, path, snapshotId, edits, signal, hooks);
  try { return await executePreparedSnapshotMutation(plan, signal, hooks); }
  finally { plan.byteEdits.length = 0; }
}

export async function executePreparedSnapshotMutation(
  plan: PreparedSnapshotMutation, signal: AbortSignal | undefined, hooks: SnapshotLineEditHooks,
): Promise<SnapshotLineEditResult> {
  const { receipt, snapshotId, patch, revisions } = plan;
  revisions.assertCurrent(receipt);
  if (await hooks.assertPathAllowed() !== receipt.canonicalPath) throw new Error("[SNAPSHOT_EDIT_PATH] Prepared path changed.");
  const current = await readSnapshotSource(receipt, revisions);
  const chunks: Buffer[] = [];
  let cursor = 0;
  for (const edit of plan.byteEdits) { chunks.push(current.subarray(cursor, edit.start), edit.replacement); cursor = edit.end; }
  chunks.push(current.subarray(cursor));
  const prepared = { output: Buffer.concat(chunks), changedBytes: plan.changedBytes, replacements: plan.replacements, deduplicatedEdits: plan.deduplicatedEdits };
  const diffResult = plan;
  const reservationId = hooks.reserveMutation?.(prepared.changedBytes);
  if (signal?.aborted) throw new Error("Operation aborted");
  try {
    // One invocation-bound callback, reused by every pre-publication commit check.
    const assertCurrent = (): void => { revisions.assertCurrent(receipt); hooks.assertCurrent?.(); };
    const metadata = await selectCommitMetadata(plan.target);
    signal?.throwIfAborted(); assertCurrent();
    hooks.commitSelected?.(metadata);
    const commit = await commitPreparedFile({ target: plan.target, parent: plan.parent, previousSha256: receipt.sha256, metadata }, prepared.output, { ...hooks, signal, assertCurrent });
    revisions.forget(snapshotId);
    return {
      commit,
      previousSha256: receipt.sha256,
      sha256: sha256(prepared.output),
      replacements: prepared.replacements,
      deduplicatedEdits: prepared.deduplicatedEdits,
      changedBytes: prepared.changedBytes,
      diff: diffResult.diff,
      patch,
      firstChangedLine: diffResult.firstChangedLine,
      reservationId,
    };
  } catch (error) {
    if (error instanceof FileCommitError) {
      revisions.forget(snapshotId);
      error.message = `${error.receipt.outcome === "not_committed" ? "[SNAPSHOT_EDIT_STALE] Failed before commit:" : "[SNAPSHOT_EDIT_PARTIAL]"} ${error.message}`;
    }
    throw error;
  }
}
