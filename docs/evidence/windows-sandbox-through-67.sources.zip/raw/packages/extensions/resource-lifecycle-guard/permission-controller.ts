import { prepareShellCwd } from "@super-pi/coding-agent";
import { createHash } from "node:crypto";
import { lstat, realpath } from "node:fs/promises";
import { dirname, isAbsolute, resolve } from "node:path";
import type { ExtensionAPI, ExtensionCommandContext, ExtensionContext } from "@super-pi/coding-agent";
import { inspectHighRiskBashMutation, type HighRiskMutationScan } from "./core.ts";
import { inspectBashPermissionScope } from "./permission-bash.ts";
import { ShellAnalysisOwner } from "./shell-analysis.ts";
import { inspectPowerShellPermissionScope } from "./permission-powershell.ts";
import {
  attachBrowserExecAuthorization,
  browserExecRequestHash,
  attachPermissionPathApproval,
  attachStructuredReadonlyWorkspaceDelegation,
  attachSubagentWorkspaceDelegation,
  mutationRequestHash,
  structuredReadonlyRequestHash,
  SESSION_PERMISSION_AUDIT_TYPE,
  SESSION_PERMISSION_EVENT,
  SESSION_PERMISSION_STATE_TYPE,
  type SessionAllowRuleKind,
  type SessionApprovalPolicy,
  type SessionPermissionMode,
  type StructuredReadonlyPathGrant,
  type SubagentWorkspaceGrant,
} from "./permission-contract.ts";
import { createSessionAllowRule, sessionAllowRuleMatches, simpleCommandPrefix } from "./permission-rule.ts";
import {
  isSessionApprovalPolicy,
  isSessionPermissionMode,
  SessionPermissionState,
  type PermissionStateCheckpoint,
  type PermissionTargetAssessment,
} from "./permission-state.ts";
import { protectedRootViolations } from "./mutation-policy.ts";
import { assessProtectedMutationPath } from "../mutation-guard-write/protected-path-policy.ts";
import { prepareNativeOperation, type NativePlan } from "../mutation-guard-write/native-file-core.ts";
import { prepareFileCreation, type FileCreationPlan } from "../mutation-guard-write/file-creation.ts";
import { getBatchPreparation } from "../mutation-guard-write/file-batch.ts";
import { classifyStructuredReadonlyArguments, type StructuredReadonlyCommandName } from "./structured-argv.ts";
import { sanitizePolicyFeedback, type PolicyDiagnosticMetadata } from "./policy-diagnostics.ts";
import { InputReadPolicyLease } from "@super-pi/coding-agent/internal/files/session-input-read-permission";
import { InputWorkspaceGrantLease, freezeInputReadPaths, inputWorkspaceData, type InputWorkspaceGrant,
  type InputWorkspaceBinding, type InputWorkspaceIssuance } from "@super-pi/coding-agent/internal/files/input-workspace-grant-lease";
import { relative as inputWorkspaceRelative } from "node:path";

const STATUS_KEY = "session-permissions";
const MAX_PURPOSE_CHARS = 800;
const MAX_COMMAND_DISPLAY_CHARS = 4_000;
const MAX_REJECTION_CHARS = 800;
const MAX_REJECTIONS = 32;
const MODE_LABELS: Record<SessionPermissionMode, string> = {
  "read-only": "1 · 只读",
  "workspace-write": "2 · 工作区读写（默认）",
  "full-access": "3 · 全部读写",
};
const MODE_CHOICES = [MODE_LABELS["read-only"], MODE_LABELS["workspace-write"], MODE_LABELS["full-access"]];
const LABEL_TO_MODE = new Map<string, SessionPermissionMode>([
  [MODE_LABELS["read-only"], "read-only"],
  [MODE_LABELS["workspace-write"], "workspace-write"],
  [MODE_LABELS["full-access"], "full-access"],
]);
const APPROVAL_LABELS: Record<SessionApprovalPolicy, string> = {
  ask: "审批 · 按需询问（默认）",
  "never-ask": "审批 · 已知范围内不询问（未知/高风险仍确认）",
};
const APPROVAL_CHOICES = [APPROVAL_LABELS.ask, APPROVAL_LABELS["never-ask"]];
const LABEL_TO_APPROVAL = new Map<string, SessionApprovalPolicy>([
  [APPROVAL_LABELS.ask, "ask"],
  [APPROVAL_LABELS["never-ask"], "never-ask"],
]);
const MANAGE_RULES = "管理当前 Session 指令白名单";
const APPROVAL_FLOW_CHOICES = [...APPROVAL_CHOICES, MANAGE_RULES];
const ALLOW_ONCE = "仅允许本次";
const ALLOW_SESSION_EXACT = "将当前完整指令加入 Session 白名单";
const ALLOW_SESSION_PREFIX = "将当前指令前缀加入 Session 白名单";
const ADD_EXACT_RULE = "添加精确指令白名单";
const ADD_PREFIX_RULE = "添加指令前缀白名单";
const SWITCH_WORKSPACE = "切换到工作区读写并允许";
const SWITCH_FULL = "切换到全部读写并允许";
const CLEAR_RULES = "清空全部 Session 白名单";
const BACK = "返回";
const REJECT_REASON = "拒绝并填写理由";
const REJECT = "拒绝";
const EDIT_CLASSES = ["file:edit"] as const;
const WRITE_CLASSES = ["file:write"] as const;
const LSP_FIX_CLASSES = ["file:lsp_fix"] as const;

function permissionCancellation(message: string): Error {
  const error = new Error(message);
  // Abort reasons outlive the issuer. V8's lazy CallSite objects can retain its receiver.
  error.stack = `Error: ${message}`;
  return error;
}

interface ToolCallEventShape {
  toolName: string;
  toolCallId: string;
  input: unknown;
}

interface ToolCallBlock {
  block: true;
  reason: string;
  details?: unknown;
}

interface SubagentInputShape {
  agent?: unknown;
  task?: unknown;
  cwd?: unknown;
  readOnly?: unknown;
  tasks?: unknown;
  chain?: unknown;
}

interface SubagentTaskRequest {
  cwd: string;
  readOnly: boolean;
}

function subagentTaskRequests(input: unknown, defaultCwd: string): SubagentTaskRequest[] | undefined {
  if (!input || typeof input !== "object") return undefined;
  const value = input as SubagentInputShape;
  const hasTasks = Array.isArray(value.tasks) && value.tasks.length > 0;
  const hasChain = Array.isArray(value.chain) && value.chain.length > 0;
  const hasSingle = typeof value.agent === "string" && typeof value.task === "string";
  if (Number(hasTasks) + Number(hasChain) + Number(hasSingle) !== 1) return undefined;
  const items = hasTasks ? value.tasks as unknown[] : hasChain ? value.chain as unknown[] : [value];
  const requests: SubagentTaskRequest[] = [];
  for (const item of items) {
    if (!item || typeof item !== "object") return undefined;
    const task = item as { cwd?: unknown; readOnly?: unknown };
    if (task.cwd !== undefined && typeof task.cwd !== "string") return undefined;
    if (task.readOnly !== undefined && typeof task.readOnly !== "boolean") return undefined;
    requests.push({ cwd: task.cwd ?? defaultCwd, readOnly: task.readOnly === true });
  }
  return requests;
}

interface OperationRequest {
  operation: "edit" | "write" | "lsp_fix" | "bash" | "powershell" | "browser_exec" | "delete" | "move" | "file_batch";
  batch?: true;
  readOnlyPreview?: boolean;
  nativePlan?: NativePlan;
  creationPlan?: FileCreationPlan;
  requestHash?: string;
  purpose?: string;
  summary: string;
  exactTargets: string[];
  targetAssessments: PermissionTargetAssessment[];
  classes: readonly string[];
  pathApproval?: { canonicalTarget: string; protectedRoots: string[] };
  highRisk: boolean;
  catastrophicRoots?: string[];
  opaqueScript: boolean;
  primitives: string[];
  fingerprintMaterial: string;
  shellCommand?: string;
  effectiveCwd?: string;
  diagnostic?: PolicyDiagnosticMetadata;
}

interface RejectionRecord {
  reason?: string;
}

function boundedText(value: string, max: number): string {
  const trimmed = value.trim();
  return trimmed.length <= max ? trimmed : `${trimmed.slice(0, max - 1)}…`;
}

function displayRuleId(id: string): string {
  return id.length <= 12 ? id : id.slice(0, 12);
}

function operationPurpose(event: ToolCallEventShape, ctx: ExtensionContext): string | undefined {
  if (event.input && typeof event.input === "object" && "purpose" in event.input) {
    const value = (event.input as { purpose?: unknown }).purpose;
    if (typeof value === "string" && value.trim()) return boundedText(value, MAX_PURPOSE_CHARS);
  }
  const branch = ctx.sessionManager.getBranch();
  for (let entryIndex = branch.length - 1; entryIndex >= 0; entryIndex--) {
    const entry = branch[entryIndex] as { type?: unknown; message?: unknown };
    if (entry?.type !== "message" || !entry.message || typeof entry.message !== "object") continue;
    const message = entry.message as { role?: unknown; content?: unknown };
    if (message.role !== "assistant" || !Array.isArray(message.content)) continue;
    let latestText: string | undefined;
    for (const part of message.content) {
      if (!part || typeof part !== "object") continue;
      const content = part as { type?: unknown; text?: unknown; id?: unknown };
      if (content.type === "text" && typeof content.text === "string" && content.text.trim()) {
        latestText = boundedText(content.text, MAX_PURPOSE_CHARS);
        continue;
      }
      if (content.type === "toolCall" && content.id === event.toolCallId) return latestText;
    }
  }
  return undefined;
}

function structuredPermissionBlock(
  operation: string,
  mode: SessionPermissionMode,
  policyReason: string,
  options: {
    highRisk?: boolean;
    opaqueScript?: boolean;
    retryable?: boolean;
    rejectionReason?: string;
    primitives?: readonly string[];
  } = {},
): string {
  const primitives = options.primitives ?? [];
  const workspaceEscape = primitives.includes("workspace_escape")
    && (policyReason === "scope_denied" || policyReason === "confirmation_required");
  const legalNextStep = operation === "structured_readonly_command"
    ? "Ask the user to add the exact read root with /add_workspace <path>, or change access through /permissions. Do not retry through Bash or another tool."
    : operation === "browser_exec"
      ? "Change /permissions or approve this exact browser script."
      : "Ask the user to add the exact target directory with /add_workspace <path>, or to change access through /permissions. Do not retry the mutation through Bash or an ad-hoc script.";
  if (operation === "structured_readonly_command") {
    let reason = `POLICY_BLOCKED: ${operation}: ${policyReason}`;
    if (primitives.length > 0) reason += ` (${primitives.join(", ")})`;
    reason += ".";
    if (workspaceEscape) reason += ` Retry: ${legalNextStep}`;
    return reason;
  }
  return JSON.stringify({
    ok: false,
    category: "POLICY_BLOCKED",
    operation,
    permissionMode: mode,
    policyReason,
    highRisk: options.highRisk === true,
    opaqueScript: options.opaqueScript === true,
    primitives,
    rejectionReason: sanitizePolicyFeedback(options.rejectionReason),
    stateChanged: false,
    retryable: options.retryable ?? true,
    ...(workspaceEscape ? { legalNextStep } : {}),
  });
}

function structuredInputValidationBlock(operation: string, message: string): string {
  if (operation === "structured_readonly_command") {
    return `INPUT_VALIDATION: ${operation}: ${message}`;
  }
  return JSON.stringify({
    ok: false,
    category: "INPUT_VALIDATION",
    operation,
    cause: message,
    stateChanged: false,
    retryable: false,
  });
}

function sensitiveProtectedRoots(roots: readonly string[]): boolean {
  for (const root of roots) if (root !== "workspace_escape") return true;
  return false;
}

function hasUnverifiableAssessment(assessments: readonly PermissionTargetAssessment[]): boolean {
  for (const assessment of assessments) if (assessment.unverifiableReason !== undefined) return true;
  return false;
}

function allTargetsInsideWorkspaces(assessments: readonly PermissionTargetAssessment[]): boolean {
  for (const assessment of assessments) if (assessment.workspace === undefined) return false;
  return true;
}

function canonicalTargets(assessments: readonly PermissionTargetAssessment[]): string[] {
  const targets: string[] = [];
  for (const assessment of assessments) if (assessment.canonicalTarget) targets.push(assessment.canonicalTarget);
  return targets;
}

function appendUniqueBounded(values: string[], value: string): boolean {
  for (const current of values) if (current === value) return true;
  if (values.length >= 16) return false;
  values.push(value);
  return true;
}

export class SessionPermissionController {
  readonly #pi: ExtensionAPI;
  readonly #state = new SessionPermissionState();
  readonly #rejections = new Map<string, RejectionRecord>();
  #committedState?: PermissionStateCheckpoint;
  #auditSequence = 0;
  #restored = false;
  #authorityGeneration = 0;
  #invocationCancellation = new AbortController();
  #pendingApproval: AbortController | undefined;
  #pendingInteraction: Promise<unknown> | undefined;
  readonly #invocationIssuer: WeakRef<SessionPermissionController>;

  constructor(pi: ExtensionAPI) {
    this.#pi = pi;
    this.#invocationIssuer = new WeakRef(this);
    pi.registerExecutionOwner?.("permissions", { revoke: this.#revokeExecution, drain: this.#drainExecution });
  }

  /** Policy settings persist; only already issued or awaiting authority becomes obsolete. */
  readonly #revokeExecution = (): void => {
    this.#authorityGeneration++;
    this.#revokeInvocations();
    this.#invocationCancellation = new AbortController();
    this.#pendingApproval?.abort(permissionCancellation("Permission request is obsolete after execution transition"));
    this.#pendingApproval = undefined;
  };
  readonly #drainExecution = async (): Promise<void> => {
    try { await this.#pendingInteraction; } catch { /* The original permission caller observes cancellation/failure. */ }
  };
  async #awaitInteraction<T>(pending: Promise<T>): Promise<T> {
    this.#pendingInteraction = pending;
    try { return await pending; }
    finally { if (this.#pendingInteraction === pending) this.#pendingInteraction = undefined; }
  }

  get state(): SessionPermissionState {
    return this.#state;
  }

  /** Read-only invalidation identity; does not grant permission or change policy. */
  get authorityGeneration(): number { return this.#authorityGeneration; }

  /** User-command observation reuses current Session scope; it grants no mutation/read evidence. */
  async authorizeFileObservation(ctx: ExtensionContext, paths: readonly string[]): Promise<(() => Promise<void>) & { assertCurrent(): void }> {
    if (!this.#restored || paths.length < 1 || paths.length > 34) throw new Error("Current Session permission state is unavailable.");
    const targets = paths.slice();
    const generation = this.#authorityGeneration, sequence = this.#state.sequence, sessionId = ctx.sessionManager.getSessionId(), cwd = ctx.cwd;
    const assertCurrent = () => {
      ctx.signal?.throwIfAborted();
      if (!this.#restored || generation !== this.#authorityGeneration || sequence !== this.#state.sequence || sessionId !== ctx.sessionManager.getSessionId() || cwd !== ctx.cwd) throw new Error("Verification permission became obsolete; reopen /changes.");
    };
    const assertAllowed = async () => {
      assertCurrent();
      for (const path of targets) {
        if (!isAbsolute(path) || path.length > 4096) throw new Error("Verification requires a recorded canonical target.");
        const assessment = await this.#state.assessTarget(path, cwd);
        if (assessment.unverifiableReason || assessment.canonicalTarget !== path || (!assessment.workspace && this.#state.mode !== "full-access")) throw new Error("Verification target is outside the current authorized scope or has changed. Use /add_workspace or /permissions explicitly.");
        const workspace = assessment.workspace;
        if (workspace) {
          const info = await lstat(workspace.canonicalPath);
          if (!info.isDirectory() || info.isSymbolicLink() || info.dev !== workspace.device || info.ino !== workspace.inode || await realpath(workspace.requestedPath) !== workspace.canonicalPath) throw new Error("Verification workspace identity changed.");
        }
      }
      assertCurrent();
    };
    await assertAllowed();
    return Object.assign(assertAllowed, { assertCurrent });
  }

  /** Input preparation only: perform the real asynchronous scope checks, then
   * retain a weak, revocable policy lease instead of the observation closure.
   * Its synchronous check does NOT repeat filesystem validation. */
  async prepareInputRead(ctx: ExtensionContext, paths: readonly string[]): Promise<InputReadPolicyLease> {
    const lease = new InputReadPolicyLease(ctx, paths, this.#captureInvocationAuthority());
    try {
      await originalInputObservation.call(this, ctx, lease.paths);
      lease.assertCurrent();
      return lease;
    } catch (error) { lease.dispose(); throw error; }
  }

  /** One exact original workspace only. No receipt/native/content authority. */
  async prepareInputWorkspaceRead(ctx: ExtensionContext, paths: readonly string[]): Promise<InputWorkspaceGrantLease> {
    const targets = freezeInputReadPaths(paths);
    const first = SessionPermissionController.#inputWorkspaceFor(this, targets[0]!);
    if (!first) throw new Error("Input requires an existing exact workspace grant.");
    const issuance = originalInputIssuance.call(this.#state, first.grant);
    const lease = new InputWorkspaceGrantLease(ctx, targets, this, first.grant, first.slot,
      this.#captureInvocationAuthority(), SessionPermissionController.#assertInputWorkspace,
      SessionPermissionController.#observeInputWorkspace, issuance);
    const assertCurrent = lease.assertCurrent; // Original instance field, captured before the await.
    try { await lease.prepare(); assertCurrent(); return lease; }
    catch (error) { disposeInputWorkspace.call(lease); throw error; }
  }

  static #inputWorkspaceFor(owner: SessionPermissionController, target: string): { grant: InputWorkspaceGrant; slot: number } | undefined {
    const primary = originalInputPrimary.call(owner.#state);
    if (inputWorkspaceInside(inputWorkspaceData(primary, "canonicalPath"), target)) return { grant: primary, slot: -1 };
    const additional = originalInputAdditional.call(owner.#state);
    if (additional.length > 16) throw new Error("Input workspace table exceeds its bound.");
    for (let index = 0; index < additional.length; index++) {
      const grant = inputWorkspaceSlot(additional, index);
      if (inputWorkspaceInside(inputWorkspaceData(grant, "canonicalPath"), target)) return { grant, slot: index };
    }
    return undefined;
  }

  static #assertInputWorkspace(issuer: object, grant: InputWorkspaceGrant, slot: number,
    binding: InputWorkspaceBinding, paths: readonly string[], issuance: InputWorkspaceIssuance | undefined): void {
    const owner = issuer as SessionPermissionController;
    const original = slot === -1 ? originalInputPrimary.call(owner.#state) : inputWorkspaceSlot(originalInputAdditional.call(owner.#state), slot);
    if (!owner.#restored || original !== grant || originalInputIssuance.call(owner.#state, grant) !== issuance
      || inputWorkspaceData(grant, "requestedPath") !== binding.requestedPath
      || inputWorkspaceData(grant, "canonicalPath") !== binding.canonicalPath
      || inputWorkspaceData(grant, "device") !== binding.device || inputWorkspaceData(grant, "inode") !== binding.inode) {
      throw new Error("Original input workspace identity changed.");
    }
    for (const path of paths) {
      const selected = SessionPermissionController.#inputWorkspaceFor(owner, path);
      if (!selected || selected.grant !== grant || selected.slot !== slot) throw new Error("Input paths changed workspace mapping.");
    }
  }

  static async #observeInputWorkspace(issuer: object, ctx: ExtensionContext, grant: InputWorkspaceGrant,
    binding: InputWorkspaceBinding, paths: readonly string[], check: () => void): Promise<void> {
    const owner = issuer as SessionPermissionController;
    const cwd = ctx.cwd;
    check();
    for (const path of paths) {
      check();
      const assessment = await owner.#state.assessTarget(path, cwd);
      check();
      if (assessment.unverifiableReason || assessment.canonicalTarget !== path || assessment.workspace !== grant) {
        throw new Error("Input target no longer matches its original workspace grant.");
      }
      const info = await lstat(binding.canonicalPath, { bigint: true });
      check();
      if (!info.isDirectory() || info.isSymbolicLink() || info.dev !== binding.identity.dev || info.ino !== binding.identity.ino) {
        throw new Error("Original input workspace filesystem identity changed.");
      }
      const canonical = await realpath(binding.requestedPath);
      check();
      if (canonical !== binding.canonicalPath) throw new Error("Original input workspace mapping changed.");
    }
    check();
  }

  registerCommands(): void {
    this.#pi.registerCommand("permissions", {
      description: "管理当前 Session 的访问范围、审批策略和指令白名单",
      handler: (args, ctx) => this.#permissionsCommand(args, ctx),
    });
    this.#pi.registerCommand("add_workspace", {
      description: "向当前 Session 添加一个具有工作区读写权限的目录",
      handler: (args, ctx) => this.#addWorkspaceCommand(args, ctx),
    });
    this.#pi.registerCommand("remove_workspace", {
      description: "从当前 Session 移除先前添加的工作区路径",
      handler: (args, ctx) => this.#removeWorkspaceCommand(args, ctx),
    });
  }

  async restore(ctx: ExtensionContext): Promise<void> {
    this.invalidate();
    this.#invocationCancellation = new AbortController();
    await this.#state.restore(ctx.cwd, ctx.sessionManager.getBranch());
    this.#committedState = this.#state.checkpoint();
    this.#rejections.clear();
    this.#publish(ctx);
    this.#restored = true;
  }

  /** Revoke live invocations before session restoration or shutdown. */
  invalidate(): void {
    this.#restored = false;
    this.#authorityGeneration++;
    this.#revokeInvocations();
    this.#pendingApproval?.abort(permissionCancellation("Permission request is obsolete after session invalidation"));
    this.#pendingApproval = undefined;
  }

  #revokeInvocations(): void {
    this.#invocationCancellation.abort(permissionCancellation("[POLICY_BLOCKED] Permission authority changed after approval."));
  }

  systemGuidance(): string {
    let workspaces = this.#state.primary.canonicalPath;
    for (const grant of this.#state.additional) workspaces += `; ${grant.canonicalPath}`;
    return `Filesystem permissions: mode=${this.#state.mode}; approval=${this.#state.approvalPolicy}; writable roots=${workspaces}. Use /permissions before accessing outside these roots; session command allow rules may apply.`;
  }

  async authorizeToolCall(event: ToolCallEventShape, ctx: ExtensionContext, analysisOwner?: ShellAnalysisOwner, opaqueScript = false): Promise<ToolCallBlock | undefined> {
    if (event.toolName !== "write" && event.toolName !== "edit" && event.toolName !== "lsp_fix" && event.toolName !== "delete" && event.toolName !== "move" && event.toolName !== "file_batch"
      && event.toolName !== "bash" && event.toolName !== "powershell" && event.toolName !== "browser_exec"
      && event.toolName !== "subagent" && event.toolName !== "structured_readonly_command") return undefined;
    if (!this.#restored) return { block: true, reason: "[SHELL_CWD_CHANGED] Permissions are unavailable until the Session workspace identity is restored; the tool was not executed." };
    let signal = ctx.signal;
    const generation = this.#authorityGeneration;
    const permissionSequence = this.#state.sequence;
    const sessionId = ctx.sessionManager.getSessionId();
    const assertCurrent = () => {
      signal?.throwIfAborted();
      if (generation !== this.#authorityGeneration || sessionId !== ctx.sessionManager.getSessionId() || permissionSequence !== this.#state.sequence) {
        throw new Error("Permission request is obsolete; no approval was committed");
      }
    };
    assertCurrent();
    if (event.toolName === "structured_readonly_command") return this.#authorizeStructuredReadonlyDelegation(event, ctx, assertCurrent);
    if (event.toolName === "subagent") return this.#authorizeSubagentDelegation(event, ctx, assertCurrent);
    const request = await this.#buildRequest(event, ctx, analysisOwner);
    assertCurrent();
    if (!request) return undefined;
    request.opaqueScript ||= opaqueScript;
    if (request.catastrophicRoots?.length) {
      this.#appendAudit(request, "blocked", "protected_root", this.#state.mode, this.#state.mode, false);
      return {
        block: true,
        reason: structuredPermissionBlock(request.operation, this.#state.mode, "protected_root", {
          highRisk: true, retryable: false, primitives: request.catastrophicRoots,
        }),
      };
    }
    const uncertainTarget = hasUnverifiableAssessment(request.targetAssessments);
    const fingerprint = createHash("sha256")
      .update(`${request.operation}\u0000${request.fingerprintMaterial}\u0000${request.purpose ?? ""}`)
      .digest("hex");
    const priorRejection = this.#rejections.get(fingerprint);
    if (priorRejection) {
      this.#appendAudit(request, "blocked", "unchanged_rejected_request", this.#state.mode, this.#state.mode, Boolean(priorRejection.reason));
      return {
        block: true,
        reason: structuredPermissionBlock(request.operation, this.#state.mode, "unchanged_rejected_request", {
          highRisk: request.highRisk, opaqueScript: request.opaqueScript,
          rejectionReason: priorRejection.reason, primitives: request.primitives,
        }),
      };
    }

    const ruleCwd = request.effectiveCwd === ctx.cwd ? this.#state.primary.canonicalPath : request.effectiveCwd ?? ctx.cwd;
    const scopeAllowed = this.#scopeAllows(request);
    if (!uncertainTarget && request.shellCommand && this.#ruleScopeAllows(request)) {
      for (const rule of this.#state.allowRules) {
        if (!rule.cwd && ruleCwd !== this.#state.primary.canonicalPath) continue;
        if (rule.kind === "prefix" && request.highRisk) continue;
        if (!sessionAllowRuleMatches(rule, request.shellCommand, { backend: request.operation, cwd: rule.cwd === ctx.cwd && ruleCwd === this.#state.primary.canonicalPath ? ctx.cwd : ruleCwd })) continue;
        this.#appendAudit(request, "approved", "session_rule_match", this.#state.mode, this.#state.mode, false);
        return undefined;
      }
    }
    if (!uncertainTarget && this.#state.approvalPolicy === "never-ask") {
      if (scopeAllowed) {
        this.#attachPathApproval(event, request);
        return undefined;
      }
      if (!request.highRisk && !request.opaqueScript) {
        this.#appendAudit(request, "blocked", "scope_denied", this.#state.mode, this.#state.mode, false);
        return {
          block: true,
          reason: structuredPermissionBlock(request.operation, this.#state.mode, "scope_denied", {
            highRisk: request.highRisk,
            opaqueScript: request.opaqueScript,
            primitives: request.primitives,
          }),
        };
      }
    }
    if (!uncertainTarget && scopeAllowed && !request.highRisk && !request.opaqueScript) {
      this.#attachPathApproval(event, request);
      return undefined;
    }

    if (!ctx.hasUI) {
      this.#appendAudit(request, "blocked", "confirmation_required", this.#state.mode, this.#state.mode, false);
      return {
        block: true,
        reason: structuredPermissionBlock(request.operation, this.#state.mode, "confirmation_required", {
          highRisk: request.highRisk,
          opaqueScript: request.opaqueScript,
          primitives: request.primitives,
        }),
      };
    }

    if (this.#pendingApproval || this.#pendingInteraction) throw new Error("Another permission request is awaiting approval");
    const approval = new AbortController();
    this.#pendingApproval = approval;
    signal = signal ? AbortSignal.any([signal, approval.signal]) : approval.signal;
    try {
    const modeBefore = this.#state.mode;
    const choices = [ALLOW_ONCE];
    const commandPrefix = request.shellCommand && !request.highRisk ? simpleCommandPrefix(request.shellCommand) : undefined;
    if (!uncertainTarget && this.#state.approvalPolicy === "ask" && request.shellCommand) {
      choices.push(ALLOW_SESSION_EXACT);
      if (commandPrefix) choices.push(`${ALLOW_SESSION_PREFIX}：${commandPrefix} *`);
    }
    if (!uncertainTarget && !request.highRisk && !request.opaqueScript) {
      const insideAuthorizedWorkspace = allTargetsInsideWorkspaces(request.targetAssessments);
      if (modeBefore === "read-only" && insideAuthorizedWorkspace) choices.push(SWITCH_WORKSPACE);
      if (modeBefore !== "full-access") choices.push(SWITCH_FULL);
    }
    choices.push(REJECT_REASON, REJECT);
    const requestKind = request.highRisk ? "高危操作" : request.opaqueScript ? "不透明脚本" : "越权文件操作";
    const context = request.operation === "browser_exec"
      ? "browser_exec Python helper runtime (not a project shell)"
      : `${request.operation}; host=${process.platform}; session cwd=${ctx.cwd}`;
    const header = `权限申请: ${request.operation} | ${requestKind}\n执行上下文: ${context}\n当前模式: ${MODE_LABELS[modeBefore]}; 审批: ${APPROVAL_LABELS[this.#state.approvalPolicy]}`;
    // One presentation materialization per actual approval. Never use the bounded
    // summary as the authority or as a substitute for inspectable request values.
    const fullRequest = JSON.stringify(event.input, null, 2);
    const details = `${header}\n操作尚未执行\n将保存的精确规则: ${request.shellCommand ?? "不适用"}\n将保存的前缀规则: ${commandPrefix ? `${commandPrefix} *（仅匹配单条简单命令，允许参数变化及无参数调用；复合命令仍需确认）` : "不适用"}\n本 Session 规则范围: ${request.operation}; cwd=${ruleCwd}\n模型提供的说明 (未经验证): ${request.purpose ?? "未提供"}\n目标范围:\n${request.exactTargets.join("\n") || "未确定"}\n风险依据: ${request.primitives.join(", ")}\n完整请求:\n${fullRequest}`;
    const choice = await this.#awaitInteraction(ctx.ui.select(header, choices, { signal, details }));
    assertCurrent();
    const prefixChoice = commandPrefix ? `${ALLOW_SESSION_PREFIX}：${commandPrefix} *` : undefined;
    const chosePrefix = prefixChoice !== undefined && choice === prefixChoice;
    if (choice && choices.includes(choice) && (choice === ALLOW_ONCE || choice === ALLOW_SESSION_EXACT || chosePrefix || choice === SWITCH_WORKSPACE || choice === SWITCH_FULL)) {
      // Selection is settled; its own approved state update must not revoke itself.
      if (this.#pendingApproval === approval) this.#pendingApproval = undefined;
      let policyReason = "user_approved_once";
      if ((choice === ALLOW_SESSION_EXACT || chosePrefix) && request.shellCommand) {
        try {
          const kind: SessionAllowRuleKind = choice === ALLOW_SESSION_EXACT ? "exact" : "prefix";
          const value = kind === "exact" ? request.shellCommand : commandPrefix!;
          if (this.#state.addAllowRule(createSessionAllowRule(kind, value, { backend: request.operation as "bash" | "powershell", cwd: ruleCwd }))) {
            this.#persist(ctx);
            policyReason = "session_rule_added";
          }
        } catch (error) {
          ctx.ui.notify(error instanceof Error ? error.message : String(error), "warning");
        }
      } else if (choice === SWITCH_WORKSPACE) {
        this.#state.setMode("workspace-write");
        policyReason = "user_switched_mode";
      } else if (choice === SWITCH_FULL) {
        this.#state.setMode("full-access");
        policyReason = "user_switched_mode";
      }
      if (this.#state.mode !== modeBefore) this.#persist(ctx);
      this.#attachPathApproval(event, request);
      this.#appendAudit(request, "approved", policyReason, modeBefore, this.#state.mode, false);
      return undefined;
    }
    if (choice !== REJECT && choice !== REJECT_REASON) {
      this.#appendAudit(request, "blocked", "confirmation_cancelled", modeBefore, this.#state.mode, false);
      return {
        block: true,
        reason: structuredPermissionBlock(request.operation, this.#state.mode, "confirmation_cancelled", {
          highRisk: request.highRisk,
          opaqueScript: request.opaqueScript,
          primitives: request.primitives,
        }),
      };
    }

    let rejectionReason: string | undefined;
    if (choice === REJECT_REASON) {
      const entered = await this.#awaitInteraction(ctx.ui.input("拒绝理由（将返回给模型）", "请说明需要修改、缩小或补充的内容", { signal }));
      assertCurrent();
      if (typeof entered === "string" && entered.trim()) rejectionReason = boundedText(entered, MAX_REJECTION_CHARS);
    }
    this.#rememberRejection(fingerprint, rejectionReason);
    this.#appendAudit(request, "blocked", "user_rejected", modeBefore, this.#state.mode, Boolean(rejectionReason));
    return {
      block: true,
      reason: structuredPermissionBlock(request.operation, this.#state.mode, "user_rejected", {
        highRisk: request.highRisk,
        opaqueScript: request.opaqueScript,
        rejectionReason,
        primitives: request.primitives,
      }),
    };
    } finally {
      if (this.#pendingApproval === approval) this.#pendingApproval = undefined;
      approval.abort(permissionCancellation("Permission interaction ended"));
    }
  }

  async #authorizeStructuredReadonlyDelegation(
    event: ToolCallEventShape,
    ctx: ExtensionContext,
    assertCurrent: () => void,
  ): Promise<ToolCallBlock | undefined> {
    if (!event.input || typeof event.input !== "object") {
      return { block: true, reason: structuredInputValidationBlock("structured_readonly_command", "Input must be an object.") };
    }
    const structuredInput = event.input as { cwd?: unknown; command?: unknown; args?: unknown };
    const rawCwd = structuredInput.cwd;
    if (rawCwd !== undefined && typeof rawCwd !== "string") {
      return { block: true, reason: structuredInputValidationBlock("structured_readonly_command", "cwd must be a string.") };
    }
    if (structuredInput.command !== "rg" && structuredInput.command !== "git") {
      return { block: true, reason: structuredInputValidationBlock("structured_readonly_command", "command must be rg or git.") };
    }
    if (!Array.isArray(structuredInput.args)) {
      return { block: true, reason: structuredInputValidationBlock("structured_readonly_command", "args must be an array of strings.") };
    }
    for (const argument of structuredInput.args) {
      if (typeof argument !== "string") {
        return { block: true, reason: structuredInputValidationBlock("structured_readonly_command", "args must be an array of strings.") };
      }
    }
    const assessment = await this.#state.assessTarget(rawCwd ?? ctx.cwd, ctx.cwd);
    if (assessment.unverifiableReason || !assessment.canonicalTarget) {
      return {
        block: true,
        reason: structuredPermissionBlock("structured_readonly_command", this.#state.mode, "unverifiable_target", {
          retryable: false,
          primitives: ["workspace_escape"],
        }),
      };
    }
    if (!assessment.workspace && this.#state.mode !== "full-access") {
      return {
        block: true,
        reason: structuredPermissionBlock("structured_readonly_command", this.#state.mode, "scope_denied", {
          primitives: ["workspace_escape"],
        }),
      };
    }
    const canonicalRoot = assessment.workspace?.canonicalPath ?? assessment.canonicalTarget;
    let rootInfo;
    let cwdInfo;
    try {
      [rootInfo, cwdInfo] = await Promise.all([lstat(canonicalRoot), lstat(assessment.canonicalTarget)]);
    } catch {
      rootInfo = undefined;
      cwdInfo = undefined;
    }
    if (!rootInfo?.isDirectory() || rootInfo.isSymbolicLink() || !cwdInfo?.isDirectory() || cwdInfo.isSymbolicLink()) {
      return {
        block: true,
        reason: structuredPermissionBlock("structured_readonly_command", this.#state.mode, "unverifiable_target", {
          retryable: false,
          primitives: ["workspace_escape"],
        }),
      };
    }
    const source: StructuredReadonlyPathGrant["source"] = assessment.workspace
      ? assessment.workspace.canonicalPath === this.#state.primary.canonicalPath ? "primary" : "additional"
      : "full-access-exact";
    const additionalRoots: StructuredReadonlyPathGrant[] = [];
    const pathArguments = classifyStructuredReadonlyArguments(
      structuredInput.command as StructuredReadonlyCommandName,
      structuredInput.args,
    ).pathArguments;
    for (const argument of pathArguments) {
      const pathValue = argument.startsWith("@") ? argument.slice(1) : argument;
      if (!isAbsolute(pathValue)) continue;
      const pathAssessment = await this.#state.assessTarget(pathValue, ctx.cwd);
      if (pathAssessment.unverifiableReason || !pathAssessment.canonicalTarget) {
        return {
          block: true,
          reason: structuredPermissionBlock("structured_readonly_command", this.#state.mode, "unverifiable_target", {
            retryable: false,
            primitives: ["workspace_escape"],
          }),
        };
      }
      if (!pathAssessment.workspace && this.#state.mode !== "full-access") {
        return {
          block: true,
          reason: structuredPermissionBlock("structured_readonly_command", this.#state.mode, "scope_denied", {
            primitives: ["workspace_escape"],
          }),
        };
      }
      let targetInfo;
      try {
        targetInfo = await lstat(pathAssessment.canonicalTarget);
      } catch {
        targetInfo = undefined;
      }
      if (!targetInfo || targetInfo.isSymbolicLink()) {
        return {
          block: true,
          reason: structuredPermissionBlock("structured_readonly_command", this.#state.mode, "unverifiable_target", {
            retryable: false,
            primitives: ["workspace_escape"],
          }),
        };
      }
      const argumentRoot = pathAssessment.workspace?.canonicalPath
        ?? (targetInfo.isDirectory() ? pathAssessment.canonicalTarget : dirname(pathAssessment.canonicalTarget));
      let alreadyAuthorized = argumentRoot === canonicalRoot;
      if (!alreadyAuthorized) {
        for (const grant of additionalRoots) {
          if (grant.canonicalRoot !== argumentRoot) continue;
          alreadyAuthorized = true;
          break;
        }
      }
      if (alreadyAuthorized) continue;
      if (additionalRoots.length >= 16) {
        return { block: true, reason: structuredInputValidationBlock("structured_readonly_command", "At most 16 distinct external argument roots are allowed.") };
      }
      const argumentRootInfo = argumentRoot === pathAssessment.canonicalTarget
        ? targetInfo
        : await lstat(argumentRoot);
      additionalRoots.push({
        canonicalRoot: argumentRoot,
        rootDevice: argumentRootInfo.dev,
        rootInode: argumentRootInfo.ino,
        source: pathAssessment.workspace
          ? pathAssessment.workspace.canonicalPath === this.#state.primary.canonicalPath ? "primary" : "additional"
          : "full-access-exact",
      });
    }
    assertCurrent();
    attachStructuredReadonlyWorkspaceDelegation(event.input, {
      schemaVersion: 1,
      assertCurrent: this.#captureInvocationAuthority(),
      revocationSignal: this.#invocationCancellation.signal,
      sequence: this.#state.sequence,
      toolCallId: event.toolCallId,
      requestHash: structuredReadonlyRequestHash(event.input),
      canonicalRoot,
      rootDevice: rootInfo.dev,
      rootInode: rootInfo.ino,
      canonicalCwd: assessment.canonicalTarget,
      cwdDevice: cwdInfo.dev,
      cwdInode: cwdInfo.ino,
      source,
      additionalRoots,
    });
    return undefined;
  }

  async #authorizeSubagentDelegation(event: ToolCallEventShape, ctx: ExtensionContext, assertCurrent: () => void): Promise<ToolCallBlock | undefined> {
    const taskRequests = subagentTaskRequests(event.input, ctx.cwd);
    if (!taskRequests) {
      return {
        block: true,
        reason: structuredInputValidationBlock(
          "subagent",
          "Provide exactly one of single, parallel tasks, or chain mode with string cwd values and optional boolean readOnly values.",
        ),
      };
    }
    const grants: SubagentWorkspaceGrant[] = [];
    let outsideWorkspace = false;
    for (const taskRequest of taskRequests) {
      const assessment = await this.#state.assessTarget(taskRequest.cwd, ctx.cwd);
      if (assessment.unverifiableReason || !assessment.canonicalTarget) {
        return {
          block: true,
          reason: structuredPermissionBlock("subagent", this.#state.mode, "unverifiable_target", {
            retryable: false,
            primitives: ["workspace_escape"],
          }),
        };
      }
      let info;
      try {
        info = await lstat(assessment.canonicalTarget);
      } catch {
        info = undefined;
      }
      if (!info?.isDirectory() || info.isSymbolicLink()) {
        return {
          block: true,
          reason: structuredPermissionBlock("subagent", this.#state.mode, "unverifiable_target", {
            retryable: false,
            primitives: ["workspace_escape"],
          }),
        };
      }
      let source: SubagentWorkspaceGrant["source"];
      if (assessment.workspace) {
        source = assessment.workspace.canonicalPath === this.#state.primary.canonicalPath ? "primary" : "additional";
      } else {
        outsideWorkspace = true;
        source = "full-access-exact";
      }
      const permissionMode = taskRequest.readOnly ? "read-only" : this.#state.mode;
      grants.push({
        canonicalCwd: assessment.canonicalTarget,
        device: info.dev,
        inode: info.ino,
        permissionMode,
        writable: permissionMode !== "read-only",
        source,
      });
    }

    assertCurrent();
    let approval: AbortController | undefined;
    try {
    if (outsideWorkspace && this.#state.mode !== "full-access") {
      return {
        block: true,
        reason: structuredPermissionBlock("subagent", this.#state.mode, "scope_denied", {
          primitives: ["workspace_escape"],
        }),
      };
    }
    if (outsideWorkspace && this.#state.approvalPolicy === "ask") {
      if (!ctx.hasUI) {
        return {
          block: true,
          reason: structuredPermissionBlock("subagent", this.#state.mode, "confirmation_required", {
            primitives: ["workspace_escape"],
          }),
        };
      }
      if (this.#pendingApproval || this.#pendingInteraction) throw new Error("Another permission request is awaiting approval");
      approval = new AbortController(); this.#pendingApproval = approval;
      const signal = ctx.signal ? AbortSignal.any([ctx.signal, approval.signal]) : approval.signal;
      const choice = await this.#awaitInteraction(ctx.ui.select("子代理工作区委派: subagent | 精确 cwd | 独立子进程",
        [ALLOW_ONCE, REJECT], { signal, details: `完整请求:\n${JSON.stringify(event.input, null, 2)}\n授权范围:\n${grants.map(grant => `${grant.canonicalCwd}: ${grant.permissionMode}`).join("\n")}` }));
      signal.throwIfAborted();
      assertCurrent();
      if (choice !== ALLOW_ONCE) {
        return {
          block: true,
          reason: structuredPermissionBlock("subagent", this.#state.mode, choice === REJECT ? "user_rejected" : "confirmation_cancelled", {
            primitives: ["workspace_escape"],
          }),
        };
      }
    }

    assertCurrent();
    attachSubagentWorkspaceDelegation(event.input, {
      schemaVersion: 1,
      assertCurrent: this.#captureInvocationAuthority(),
      revocationSignal: this.#invocationCancellation.signal,
      sequence: this.#state.sequence,
      toolCallId: event.toolCallId,
      grants,
    });
    return undefined;
    } finally {
      if (approval) {
        if (this.#pendingApproval === approval) this.#pendingApproval = undefined;
        approval.abort(permissionCancellation("Permission interaction ended"));
      }
    }
  }

  async #buildRequest(event: ToolCallEventShape, ctx: ExtensionContext, analysisOwner?: ShellAnalysisOwner): Promise<OperationRequest | undefined> {
    const purpose = operationPurpose(event, ctx);
    if (event.toolName === "browser_exec") {
      if (!event.input || typeof event.input !== "object") return undefined;
      const input = event.input as { code?: unknown; session?: unknown; timeoutMs?: unknown };
      if (typeof input.code !== "string") return undefined;
      const assessment = await this.#state.assessTarget(ctx.cwd, ctx.cwd);
      return {
        operation: "browser_exec",
        purpose,
        summary: boundedText(input.code, MAX_COMMAND_DISPLAY_CHARS),
        exactTargets: assessment.canonicalTarget ? [assessment.canonicalTarget] : [],
        targetAssessments: [assessment],
        classes: ["browser:exec", "opaque:python"],
        highRisk: true,
        opaqueScript: true,
        primitives: ["arbitrary_python", "filesystem_access", "network_access", "process_access"],
        fingerprintMaterial: `${input.code}\u0000${typeof input.session === "string" ? input.session : ""}\u0000${typeof input.timeoutMs === "number" ? input.timeoutMs : ""}`,
      };
    }
    if (event.toolName === "file_batch") {
      const batch = getBatchPreparation(event.input);
      if (!batch || batch.id !== event.toolCallId) throw new Error("[POLICY_BLOCKED] Missing guarded batch preparation.");
      const targetAssessments: PermissionTargetAssessment[] = [];
      const exactTargets: string[] = [];
      const primitives: string[] = [];
      let highRisk = false;
      const destructiveTargets: string[] = [];
      for (const item of batch.items) {
        if (item.native) destructiveTargets.push(item.native.source.canonical, ...(item.native.destination ? [item.native.destination] : []));
        if (item.operation === "delete") { highRisk = true; primitives.push("irreversible_delete_no_backup"); }
        if (item.operation === "move" && !primitives.includes("exclusive_link_then_unlink_non_atomic")) primitives.push("exclusive_link_then_unlink_non_atomic");
        const paths = item.native ? item.native.protectedPaths : [item.approval];
        for (const path of paths) {
          exactTargets.push(path.canonicalTarget);
          targetAssessments.push(await this.#state.assessTarget(path.canonicalTarget, ctx.cwd));
          if (sensitiveProtectedRoots(path.protectedRoots.filter(root => root !== "workspace_root"))) highRisk = true;
          for (const root of path.protectedRoots) if (!primitives.includes(root)) primitives.push(root);
        }
        if (item.creation) for (const directory of item.creation.directories) {
          if (!exactTargets.includes(directory)) { exactTargets.push(directory); targetAssessments.push(await this.#state.assessTarget(directory, ctx.cwd)); }
        }
      }
      return { operation: "file_batch", batch: true, readOnlyPreview: batch.input.dryRun === true, requestHash: batch.requestHash,
        catastrophicRoots: batch.input.dryRun ? [] : await protectedRootViolations({ targets: destructiveTargets }, ctx.cwd, this.#state.additional),
        purpose, summary: `file_batch ${batch.items.length} independent items`, exactTargets, targetAssessments,
        classes: ["file:batch"], highRisk: !batch.input.dryRun && highRisk, opaqueScript: false, primitives,
        fingerprintMaterial: batch.requestHash, pathApproval: { canonicalTarget: batch.items[0].target, protectedRoots: [] } };
    }
    if (event.toolName === "delete" || event.toolName === "move") {
      const requestHash = mutationRequestHash(event.toolName, event.input);
      const nativePlan = await prepareNativeOperation(ctx.cwd, event.toolName, event.input);
      const targets = nativePlan.protectedPaths;
      const targetAssessments: PermissionTargetAssessment[] = [];
      for (const target of targets) targetAssessments.push(await this.#state.assessTarget(target.canonicalTarget, ctx.cwd));
      const primitives = [event.toolName === "delete" ? "irreversible_delete_no_backup" : "exclusive_link_then_unlink_non_atomic"];
      for (const target of targets) for (const root of target.protectedRoots) if (!primitives.includes(root)) primitives.push(root);
      return { operation: event.toolName, purpose, summary: `${event.toolName} ${nativePlan.source.canonical}`,
        catastrophicRoots: await protectedRootViolations({ targets: [nativePlan.source.canonical, ...(nativePlan.destination ? [nativePlan.destination] : [])] }, ctx.cwd, this.#state.additional),
        nativePlan, requestHash, exactTargets: targets.map((target) => target.canonicalTarget), targetAssessments,
        classes: [`file:${event.toolName}`], highRisk: event.toolName === "delete" || targets.some((target) => sensitiveProtectedRoots(target.protectedRoots.filter((root) => root !== "workspace_root"))),
        opaqueScript: false, primitives, fingerprintMaterial: requestHash,
        pathApproval: { canonicalTarget: nativePlan.source.canonical, protectedRoots: [...targets[0].protectedRoots] } };
    }
    if (event.toolName === "edit" || event.toolName === "write" || event.toolName === "lsp_fix") {
      if (!event.input || typeof event.input !== "object" || !("path" in event.input)) return undefined;
      const rawPath = (event.input as { path?: unknown }).path;
      if (typeof rawPath !== "string") return undefined;
      const lspRoot = (event.input as { root?: unknown }).root;
      const path = event.toolName === "lsp_fix"
        ? resolve(ctx.cwd, typeof lspRoot === "string" && lspRoot.trim() ? lspRoot : ".", rawPath)
        : rawPath.startsWith("@") ? rawPath.slice(1) : rawPath;
      const requestHash = mutationRequestHash(event.toolName, event.input);
      const creationPlan = event.toolName === "write" ? await prepareFileCreation(resolve(ctx.cwd, path)) : undefined;
      const assessment = await this.#state.assessTarget(path, ctx.cwd);
      const protectedAssessment = await assessProtectedMutationPath(ctx.cwd, assessment.canonicalTarget ?? path);
      const exactTargets = assessment.canonicalTarget ? [assessment.canonicalTarget] : [];
      return {
        operation: event.toolName,
        creationPlan, requestHash,
        purpose,
        summary: `${event.toolName} ${path}`,
        exactTargets: creationPlan ? [...exactTargets, ...creationPlan.directories] : exactTargets,
        targetAssessments: [assessment],
        classes: event.toolName === "edit" ? EDIT_CLASSES : event.toolName === "write" ? WRITE_CLASSES : LSP_FIX_CLASSES,
        pathApproval: protectedAssessment.canonicalTarget
          ? { canonicalTarget: protectedAssessment.canonicalTarget, protectedRoots: protectedAssessment.violations }
          : undefined,
        highRisk: sensitiveProtectedRoots(protectedAssessment.violations),
        opaqueScript: false,
        primitives: protectedAssessment.violations,
        fingerprintMaterial: `${path}\u0000${protectedAssessment.canonicalTarget ?? ""}`,
      };
    }
    if (event.toolName !== "bash" && event.toolName !== "powershell") return undefined;
    const shellOperation = event.toolName;
    const shellInput = event.input as { command: string; cwd?: unknown };
    const cwdBinding = await prepareShellCwd(shellInput, ctx.cwd);
    const hasExplicitCwd = cwdBinding !== undefined;
    if (cwdBinding && !cwdBinding.matchesSessionRoot(this.#state.primary.canonicalPath, this.#state.primary.device, this.#state.primary.inode)) throw new Error("[SHELL_CWD_CHANGED] Session workspace identity changed before authorization.");
    const effectiveCwd = cwdBinding?.canonical ?? ctx.cwd;
    const analysis = shellOperation === "bash"
      ? analysisOwner ?? new ShellAnalysisOwner(shellInput.command, effectiveCwd, this.#authorityGeneration) : undefined;
    let high: ReturnType<typeof inspectHighRiskBashMutation>;
    let scope: ReturnType<typeof inspectBashPermissionScope>;
    try {
      analysis?.assertCurrent(shellInput.command, effectiveCwd, this.#authorityGeneration);
      high = inspectHighRiskBashMutation(event.input, effectiveCwd, shellOperation, analysis);
      if (high && !high.mutationDetected) high = undefined;
      scope = shellOperation === "powershell"
        ? inspectPowerShellPermissionScope(event.input, effectiveCwd)
        : inspectBashPermissionScope(event.input, effectiveCwd, analysis);
    } finally { if (analysis !== analysisOwner) analysis?.release(); }
    if (!scope) return undefined;
    const roots = high ? await protectedRootViolations({ targets: high.destructiveTargets ?? [], findDeleteScopes: high.findDeleteScopes }, ctx.cwd, this.#state.additional) : [];
    // Permission-scan cwd and write destinations are not deletion operands.
    if (scope.destructiveTargets || scope.moveDestinations) for (const root of await protectedRootViolations({ targets: scope.destructiveTargets ?? [], moveDestinations: scope.moveDestinations }, ctx.cwd, this.#state.additional)) {
      if (!roots.includes(root)) roots.push(root);
    }
    if (scope.unverifiableMutation && !high?.unverifiableScope) {
      high = { risk: "HIGH", mutationDetected: true, contextUncertain: true, primitives: high?.primitives ?? scope.primitives, targets: high?.targets ?? scope.targets,
        dynamicScope: true, unverifiableScope: true, workspaceWide: high?.workspaceWide ?? false };
    }
    if (high?.unverifiableScope) {
      return this.#dynamicHighRequest(event, purpose, high, roots, scope.classes, shellOperation, effectiveCwd, hasExplicitCwd);
    }
    const targets: string[] = [];
    let targetOverflow = false;
    if (hasExplicitCwd && !appendUniqueBounded(targets, effectiveCwd)) targetOverflow = true;
    if (high) for (const target of high.targets) if (!appendUniqueBounded(targets, target)) targetOverflow = true;
    for (const target of scope.targets) if (!appendUniqueBounded(targets, target)) targetOverflow = true;
    const targetAssessments: PermissionTargetAssessment[] = [];
    const primitives: string[] = [];
    let protectedTarget = false;
    if (high) for (const primitive of high.primitives) appendUniqueBounded(primitives, primitive);
    for (const primitive of scope.primitives) appendUniqueBounded(primitives, primitive);
    for (const target of targets) {
      const assessment = await this.#state.assessTarget(target, ctx.cwd);
      targetAssessments.push(assessment);
      // cwd is an access scope, not a mutation of the directory itself.
      if (hasExplicitCwd && target === effectiveCwd && !scope.targets.includes(target) && !high?.targets.includes(target)) continue;
      // Opaque execution scope alone does not establish a mutation of its cwd.
      if (scope.kind === "opaque-script" && !scope.mutationDetected && !high?.targets.includes(target)) continue;
      const protectedAssessment = await assessProtectedMutationPath(ctx.cwd, assessment.canonicalTarget ?? target);
      if (sensitiveProtectedRoots(protectedAssessment.violations)) protectedTarget = true;
      for (const violation of protectedAssessment.violations) appendUniqueBounded(primitives, violation);
    }
    if (targetOverflow) targetAssessments.push({ unverifiableReason: "unverifiable_target" });
    const command = shellInput.command;
    const diagnostic = high?.diagnostic;
    return {
      operation: shellOperation,
      purpose,
      summary: boundedText(hasExplicitCwd ? `[cwd=${effectiveCwd}] ${command}` : command, MAX_COMMAND_DISPLAY_CHARS),
      exactTargets: canonicalTargets(targetAssessments),
      targetAssessments,
      classes: scope.classes,
      highRisk: high !== undefined || protectedTarget,
      catastrophicRoots: roots,
      opaqueScript: scope.kind === "opaque-script",
      primitives,
      fingerprintMaterial: `${effectiveCwd}\u0000${command}`,
      shellCommand: command,
      effectiveCwd,
      diagnostic,
    };
  }

  #dynamicHighRequest(
    event: ToolCallEventShape,
    purpose: string | undefined,
    high: HighRiskMutationScan,
    roots: string[],
    classes: readonly string[],
    operation: "bash" | "powershell",
    effectiveCwd = "",
    hasExplicitCwd = false,
  ): OperationRequest {
    const command = (event.input as { command: string }).command;
    const primitives: string[] = [];
    for (const primitive of high.primitives) appendUniqueBounded(primitives, primitive);
    for (const root of roots) appendUniqueBounded(primitives, root);
    return {
      operation,
      purpose,
      summary: boundedText(hasExplicitCwd ? `[cwd=${effectiveCwd}] ${command}` : command, MAX_COMMAND_DISPLAY_CHARS),
      exactTargets: high.targets,
      targetAssessments: [{ unverifiableReason: "unverifiable_target" }],
      classes,
      highRisk: true,
      catastrophicRoots: roots,
      opaqueScript: true,
      primitives,
      fingerprintMaterial: `${effectiveCwd}\u0000${command}`,
      shellCommand: command,
      effectiveCwd,
      diagnostic: high.diagnostic,
    };
  }

  #captureInvocationAuthority(): () => void {
    const sequence = this.#state.sequence;
    const generation = this.#authorityGeneration;
    const issuer = this.#invocationIssuer;
    // One callback per approved invocation; no progress-event or rendering work.
    return () => {
      const current = issuer.deref();
      if (!current || !current.#restored || sequence !== current.#state.sequence || generation !== current.#authorityGeneration) {
        throw new Error("[POLICY_BLOCKED] Permission authority changed after approval.");
      }
    };
  }

  #attachPathApproval(event: ToolCallEventShape, request: OperationRequest): void {
    if (request.operation === "browser_exec") {
      attachBrowserExecAuthorization(event.input, {
        schemaVersion: 1,
        assertCurrent: this.#captureInvocationAuthority(),
        revocationSignal: this.#invocationCancellation.signal,
        sequence: this.#state.sequence,
        toolCallId: event.toolCallId,
        requestHash: browserExecRequestHash(event.input),
      });
      return;
    }
    if (!request.pathApproval || request.operation === "bash" || request.operation === "powershell") return;
    const sequence = this.#state.sequence;
    const generation = this.#authorityGeneration;
    attachPermissionPathApproval(event.input, {
      schemaVersion: 1,
      sequence: this.#state.sequence,
      toolCallId: event.toolCallId,
      operation: request.operation,
      requestHash: request.requestHash ?? mutationRequestHash(request.operation, event.input),
      nativePlan: request.nativePlan,
      creationPlan: request.creationPlan,
      writePreflight: request.operation === "write",
      revocationSignal: request.operation === "lsp_fix" ? this.#invocationCancellation.signal : undefined,
      assertCurrent: request.operation === "lsp_fix" ? this.#captureInvocationAuthority() : request.nativePlan || request.operation === "write" || request.operation === "edit" || request.batch ? () => {
        if (sequence !== this.#state.sequence || generation !== this.#authorityGeneration) throw new Error("[POLICY_BLOCKED] Permission authority changed after approval.");
      } : undefined,
      ...request.pathApproval,
    });
  }

  #scopeAllows(request: OperationRequest): boolean {
    if (request.readOnlyPreview && allTargetsInsideWorkspaces(request.targetAssessments)) return true;
    if ((request.operation === "bash" || request.operation === "powershell") && !request.highRisk && !request.opaqueScript && request.primitives.length === 0) return true;
    if (this.#state.mode === "read-only") return false;
    if (this.#state.mode === "full-access") return true;
    if (request.opaqueScript) return false;
    if (request.targetAssessments.length === 0) return false;
    for (const assessment of request.targetAssessments) if (!assessment.workspace) return false;
    return true;
  }

  #ruleScopeAllows(request: OperationRequest): boolean {
    if (this.#state.mode === "read-only") return false;
    if (this.#state.mode === "full-access") return true;
    if (request.targetAssessments.length === 0) return true;
    for (const assessment of request.targetAssessments) if (!assessment.workspace) return false;
    return true;
  }

  async #permissionsCommand(args: string, ctx: ExtensionCommandContext): Promise<void> {
    const requested = args.trim();
    if (!requested) {
      if (!ctx.hasUI) {
        ctx.ui.notify(this.#statusText(), "info");
        return;
      }
      const modeChoice = await ctx.ui.select("选择当前 Session 访问范围", MODE_CHOICES);
      const mode = modeChoice ? LABEL_TO_MODE.get(modeChoice) : undefined;
      if (!mode) {
        ctx.ui.notify(this.#statusText(), "info");
        return;
      }
      const approvalChoice = await ctx.ui.select("选择当前 Session 审批策略", APPROVAL_FLOW_CHOICES);
      if (!approvalChoice) {
        ctx.ui.notify(this.#statusText(), "info");
        return;
      }
      const policy = LABEL_TO_APPROVAL.get(approvalChoice);
      if (policy) {
        const modeChanged = this.#state.setMode(mode);
        const policyChanged = this.#state.setApprovalPolicy(policy);
        if (modeChanged || policyChanged) this.#persist(ctx);
      } else if (approvalChoice === MANAGE_RULES) {
        const rulesChanged = await this.#manageRules(ctx, false);
        if (rulesChanged) {
          this.#state.setMode(mode);
          this.#persist(ctx);
        }
      }
      this.#publish(ctx);
      ctx.ui.notify(this.#statusText(), "info");
      return;
    }
    if (requested === "status") {
      ctx.ui.notify(this.#statusText(), "info");
      return;
    }
    if (requested === "rules") {
      ctx.ui.notify(this.#rulesText(), "info");
      return;
    }
    if (requested === "clear-rules") {
      const count = this.#state.clearAllowRules();
      if (count > 0) this.#persist(ctx);
      ctx.ui.notify(`已清空 ${count} 条当前 Session 白名单。`, "info");
      return;
    }
    const addRulePrefix = "add-rule ";
    if (requested.startsWith(addRulePrefix)) {
      const value = requested.slice(addRulePrefix.length);
      const separator = value.indexOf(" ");
      const kind = separator > 0 ? value.slice(0, separator) : "";
      const pattern = separator > 0 ? value.slice(separator + 1) : "";
      if ((kind !== "exact" && kind !== "prefix") || !pattern.trim()) {
        ctx.ui.notify("Usage: /permissions add-rule <exact|prefix> <command>", "warning");
        return;
      }
      this.#addCommandRule(kind, pattern, ctx, true);
      return;
    }
    const removePrefix = "remove-rule ";
    if (requested.startsWith(removePrefix)) {
      const id = requested.slice(removePrefix.length).trim();
      const removed = this.#state.removeAllowRule(id);
      if (removed) this.#persist(ctx);
      ctx.ui.notify(removed ? `已删除 Session 白名单：${displayRuleId(removed.id)} · ${removed.label}` : `未找到或前缀不唯一：${id}`, removed ? "info" : "warning");
      return;
    }
    if (isSessionPermissionMode(requested)) {
      if (this.#state.setMode(requested)) this.#persist(ctx);
      ctx.ui.notify(this.#statusText(), "info");
      return;
    }
    if (isSessionApprovalPolicy(requested)) {
      if (this.#state.setApprovalPolicy(requested)) this.#persist(ctx);
      ctx.ui.notify(this.#statusText(), "info");
      return;
    }
    ctx.ui.notify("Usage: /permissions [read-only|workspace-write|full-access|ask|never-ask|status|rules|add-rule <exact|prefix> <command>|clear-rules|remove-rule <id>]", "warning");
  }

  async #manageRules(ctx: ExtensionCommandContext, persistChanges = true): Promise<boolean> {
    if (!ctx.hasUI) {
      ctx.ui.notify(this.#rulesText(), "info");
      return false;
    }
    const choices: string[] = [ADD_EXACT_RULE, ADD_PREFIX_RULE];
    for (const rule of this.#state.allowRules) choices.push(`${displayRuleId(rule.id)} · ${rule.label}`);
    if (this.#state.allowRules.length > 0) choices.push(CLEAR_RULES);
    choices.push(BACK);
    const choice = await ctx.ui.select("管理当前 Session 指令白名单", choices);
    if (!choice || choice === BACK) return false;
    if (choice === ADD_EXACT_RULE || choice === ADD_PREFIX_RULE) {
      if (this.#state.approvalPolicy !== "ask") {
        ctx.ui.notify("只有在审批策略为 ask 时才能添加 Session 白名单；已有规则仍会继续生效。", "warning");
        return false;
      }
      const kind: SessionAllowRuleKind = choice === ADD_EXACT_RULE ? "exact" : "prefix";
      const prompt = kind === "exact" ? "输入要精确匹配的完整 Bash 指令" : "输入指令前缀，例如 bun 或 bun run（末尾 * 可省略）";
      const value = await ctx.ui.input(choice, prompt);
      if (!value?.trim()) return false;
      return this.#addCommandRule(kind, value, ctx, persistChanges);
    }
    if (choice === CLEAR_RULES) {
      const count = this.#state.clearAllowRules();
      if (count > 0 && persistChanges) this.#persist(ctx);
      ctx.ui.notify(`已清空 ${count} 条当前 Session 白名单。`, "info");
      return count > 0;
    }
    for (const rule of this.#state.allowRules) {
      if (choice !== `${displayRuleId(rule.id)} · ${rule.label}`) continue;
      this.#state.removeAllowRule(rule.id);
      if (persistChanges) this.#persist(ctx);
      ctx.ui.notify(`已删除 Session 白名单：${displayRuleId(rule.id)} · ${rule.label}`, "info");
      return true;
    }
    return false;
  }

  #addCommandRule(kind: SessionAllowRuleKind, value: string, ctx: ExtensionContext, persistChanges: boolean): boolean {
    if (this.#state.approvalPolicy !== "ask") {
      ctx.ui.notify("只有在审批策略为 ask 时才能添加 Session 白名单；请先执行 /permissions ask。", "warning");
      return false;
    }
    try {
      const rule = createSessionAllowRule(kind, value, { backend: "bash", cwd: ctx.cwd });
      const added = this.#state.addAllowRule(rule);
      if (added && persistChanges) this.#persist(ctx);
      ctx.ui.notify(added ? `已添加 Session 白名单：${displayRuleId(rule.id)} · ${rule.label}` : `Session 白名单已存在：${displayRuleId(rule.id)} · ${rule.label}`, "info");
      return added;
    } catch (error) {
      ctx.ui.notify(error instanceof Error ? error.message : String(error), "warning");
      return false;
    }
  }

  async #addWorkspaceCommand(args: string, ctx: ExtensionCommandContext): Promise<void> {
    let path = args.trim();
    if (!path && ctx.hasUI) path = (await ctx.ui.input("添加工作区", "输入现存目录的完整路径"))?.trim() ?? "";
    if (!path) {
      ctx.ui.notify("Usage: /add_workspace <path>", "warning");
      return;
    }
    try {
      const grant = await this.#state.addWorkspace(path, ctx.cwd);
      this.#persist(ctx);
      this.#publish(ctx);
      ctx.ui.notify(`已添加当前 Session 工作区：${grant.requestedPath}\nCanonical: ${grant.canonicalPath}`, "info");
    } catch (error) {
      ctx.ui.notify(error instanceof Error ? error.message : String(error), "error");
    }
  }

  async #removeWorkspaceCommand(args: string, ctx: ExtensionCommandContext): Promise<void> {
    let path = args.trim();
    if (!path && ctx.hasUI) path = (await ctx.ui.input("移除工作区", "输入添加时使用的相同路径"))?.trim() ?? "";
    if (!path) {
      ctx.ui.notify("Usage: /remove_workspace <path>", "warning");
      return;
    }
    try {
      const grant = await this.#state.removeWorkspace(path, ctx.cwd);
      this.#persist(ctx);
      this.#publish(ctx);
      ctx.ui.notify(`已移除当前 Session 工作区：${grant.requestedPath}`, "info");
    } catch (error) {
      ctx.ui.notify(error instanceof Error ? error.message : String(error), "error");
    }
  }

  #persist(ctx: ExtensionContext): void {
    this.#pendingApproval?.abort(permissionCancellation("Permission request is obsolete after permission state change"));
    this.#pendingApproval = undefined;
    const state = this.#state.serialized();
    try {
      this.#pi.appendEntry(SESSION_PERMISSION_STATE_TYPE, state);
    } catch (error) {
      if (this.#committedState) this.#state.restoreCheckpoint(this.#committedState);
      this.#publish(ctx);
      throw error;
    }
    this.#committedState = this.#state.checkpoint();
    this.#revokeInvocations();
    this.#invocationCancellation = new AbortController();
    try {
      this.#pi.events.emit(SESSION_PERMISSION_EVENT, state);
    } catch {
      // The durable Session entry is authoritative; event delivery is best-effort.
    }
    this.#publish(ctx);
  }

  #publish(ctx: ExtensionContext): void {
    const workspaceSuffix = this.#state.additional.length > 0 ? ` +${this.#state.additional.length}` : "";
    const ruleSuffix = this.#state.allowRules.length > 0 ? ` r${this.#state.allowRules.length}` : "";
    ctx.ui.setStatus(STATUS_KEY, `permission: ${this.#state.mode}/${this.#state.approvalPolicy}${workspaceSuffix}${ruleSuffix}`);
  }

  #statusText(): string {
    const lines = [
      `当前 Session 访问范围：${MODE_LABELS[this.#state.mode]}`,
      `审批策略：${APPROVAL_LABELS[this.#state.approvalPolicy]}`,
      `指令白名单：${this.#state.allowRules.length} 条`,
      `主工作区：${this.#state.primary.canonicalPath}`,
      "附加工作区：",
    ];
    if (this.#state.additional.length === 0) lines.push("- 无");
    else for (const grant of this.#state.additional) lines.push(`- ${grant.requestedPath} -> ${grant.canonicalPath}`);
    return lines.join("\n");
  }

  #rulesText(): string {
    if (this.#state.allowRules.length === 0) return "当前 Session 没有指令白名单。";
    const lines = [`当前 Session 指令白名单（${this.#state.allowRules.length}）：`];
    for (const rule of this.#state.allowRules) lines.push(`- ${displayRuleId(rule.id)} · ${rule.label} · backend=${rule.backend ?? "bash (legacy)"} · cwd=${rule.cwd ?? "unscoped (legacy)"}`);
    return lines.join("\n");
  }

  #rememberRejection(fingerprint: string, reason: string | undefined): void {
    this.#rejections.delete(fingerprint);
    this.#rejections.set(fingerprint, { reason });
    while (this.#rejections.size > MAX_REJECTIONS) {
      const oldest = this.#rejections.keys().next().value;
      if (oldest === undefined) break;
      this.#rejections.delete(oldest);
    }
  }

  #appendAudit(
    request: OperationRequest,
    outcome: "approved" | "blocked",
    policyReason: string,
    modeBefore: SessionPermissionMode,
    modeAfter: SessionPermissionMode,
    rejectionReasonProvided: boolean,
  ): void {
    try {
      this.#pi.appendEntry(SESSION_PERMISSION_AUDIT_TYPE, {
        schemaVersion: 1,
        controllerVersion: "1.5.0-pi.84.1",
        operation: request.operation,
        outcome,
        policyReason,
        modeBefore,
        modeAfter,
        approvalPolicy: this.#state.approvalPolicy,
        allowRuleCount: this.#state.allowRules.length,
        highRisk: request.highRisk,
        opaqueScript: request.opaqueScript,
        primitives: request.primitives,
        targetCount: request.exactTargets.length,
        purposeProvided: request.purpose !== undefined,
        rejectionReasonProvided,
        sequence: ++this.#auditSequence,
      });
      if ((request.operation === "bash" || request.operation === "powershell") && request.highRisk) {
        this.#pi.appendEntry("resource-mutation-policy-v1", {
          schemaVersion: 1,
          guardVersion: "0.8.3-pi.84.1",
          operation: request.operation,
          risk: "HIGH",
          outcome,
          policyReason,
          parserVersion: 2,
          primitives: request.primitives,
          targetsInspected: request.exactTargets.length,
          dynamicScope: request.opaqueScript,
          unverifiableScope: request.opaqueScript,
          workspaceWide: false,
          sequence: this.#auditSequence,
        });
      }
    } catch {
      // Auditing is best-effort; enforcement remains active.
    }
  }
}
const originalInputObservation = SessionPermissionController.prototype.authorizeFileObservation;
const originalInputPrimary = Object.getOwnPropertyDescriptor(SessionPermissionState.prototype, "primary")!.get!;
const originalInputAdditional = Object.getOwnPropertyDescriptor(SessionPermissionState.prototype, "additional")!.get!;
const originalInputIssuance = SessionPermissionState.prototype.getIssuedWorkspaceIdentity;
const disposeInputWorkspace = InputWorkspaceGrantLease.prototype.dispose;
function inputWorkspaceInside(root: string, target: string): boolean {
  if (typeof root !== "string" || root.length < 1 || root.length > 4096) throw new Error("Input workspace path exceeds its bound.");
  const value = inputWorkspaceRelative(root, target);
  return value === "" || !value.startsWith("..") && !isAbsolute(value);
}
function inputWorkspaceSlot(grants: readonly InputWorkspaceGrant[], index: number): InputWorkspaceGrant {
  const field = Object.getOwnPropertyDescriptor(grants, String(index));
  if (!field || !("value" in field) || !field.value) throw new Error("Original workspace slot is unavailable.");
  return field.value;
}
